from typing import Optional
from uuid import UUID
from sempy._utils._log import log
import base64
import json
import re

# ---------------------------------------------------------------------------
# Widget CSS (scoped under .slls-lv). Tokens mirror sempy_labs._ui_components
# light/dark palettes so the tool matches every other interactive widget.
# ---------------------------------------------------------------------------
_WIDGET_CSS = """
.slls-lv {
    --slls-bg-solid: #ffffff;
    --slls-bg-secondary: #f5f5f7;
    --slls-surface: rgba(255, 255, 255, 0.85);
    --slls-surface-2: rgba(0, 0, 0, 0.025);
    --slls-border: rgba(0, 0, 0, 0.08);
    --slls-border-strong: rgba(0, 0, 0, 0.14);
    --slls-text: #1d1d1f;
    --slls-text-secondary: #6e6e73;
    --slls-text-tertiary: #86868b;
    --slls-accent: #0071e3;
    --slls-accent-hover: #0a6cdb;
    --slls-accent-soft: rgba(0, 113, 227, 0.12);
    --slls-danger: #ff3b30;
    --slls-danger-soft: rgba(255, 59, 48, 0.12);
    --slls-success: #34c759;
    --slls-success-soft: rgba(52, 199, 89, 0.14);
    --slls-warn: #ff9500;
    --slls-radius: 14px;
    --slls-radius-sm: 8px;
    --slls-shadow: 0 1px 2px rgba(0,0,0,0.04), 0 8px 24px rgba(0,0,0,0.06);
    --ui-bg: var(--slls-bg-solid);
    --ui-bg-solid: var(--slls-bg-solid);
    --ui-bg-secondary: var(--slls-bg-secondary);
    --ui-surface: var(--slls-surface);
    --ui-surface-2: var(--slls-surface-2);
    --ui-border: var(--slls-border);
    --ui-border-strong: var(--slls-border-strong);
    --ui-text: var(--slls-text);
    --ui-text-secondary: var(--slls-text-secondary);
    --ui-text-tertiary: var(--slls-text-tertiary);
    --ui-accent: var(--slls-accent);
    --ui-accent-soft: var(--slls-accent-soft);
    --ui-shadow-lg: var(--slls-shadow);
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display",
        "Helvetica Neue", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: var(--slls-text);
    width: 100%;
    background: var(--slls-bg-solid);
    border: 1px solid var(--slls-border);
    border-radius: var(--slls-radius);
    box-shadow: var(--slls-shadow);
    box-sizing: border-box;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-height: 620px;
}
@media (prefers-color-scheme: dark) {
    .slls-lv.slls-lv-auto {
        --slls-bg-solid: #1e1e22; --slls-bg-secondary: #2a2a30;
        --slls-surface: rgba(255,255,255,0.04); --slls-surface-2: rgba(255,255,255,0.03);
        --slls-border: rgba(255,255,255,0.08); --slls-border-strong: rgba(255,255,255,0.16);
        --slls-text: #f5f5f7; --slls-text-secondary: #b8b8bf; --slls-text-tertiary: #8e8e94;
        --slls-accent: #0A84FF; --slls-accent-hover: #1a8cff; --slls-accent-soft: rgba(10,132,255,0.18);
        --slls-danger: #ff453a; --slls-danger-soft: rgba(255,69,58,0.18);
        --slls-success: #30d158; --slls-success-soft: rgba(48,209,88,0.18);
        --slls-shadow: 0 1px 2px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.5);
    }
}
.slls-lv.slls-lv-dark {
    --slls-bg-solid: #1e1e22; --slls-bg-secondary: #2a2a30;
    --slls-surface: rgba(255,255,255,0.04); --slls-surface-2: rgba(255,255,255,0.03);
    --slls-border: rgba(255,255,255,0.08); --slls-border-strong: rgba(255,255,255,0.16);
    --slls-text: #f5f5f7; --slls-text-secondary: #b8b8bf; --slls-text-tertiary: #8e8e94;
    --slls-accent: #0A84FF; --slls-accent-hover: #1a8cff; --slls-accent-soft: rgba(10,132,255,0.18);
    --slls-danger: #ff453a; --slls-danger-soft: rgba(255,69,58,0.18);
    --slls-success: #30d158; --slls-success-soft: rgba(48,209,88,0.18);
    --slls-shadow: 0 1px 2px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.5);
}
.slls-lv * { box-sizing: border-box; }

/* Fullscreen: fill the whole screen and drop the framing chrome. Notebook
   hosts often block the native Fullscreen API, so a CSS overlay (position:
   fixed covering the viewport) is used as the reliable primary mechanism. */
.slls-lv:fullscreen, .slls-lv:-webkit-full-screen { width: 100vw; height: 100vh; max-height: none; border: none; border-radius: 0; box-shadow: none; }
.slls-lv.slls-lv-fs { position: fixed; inset: 0; z-index: 2147483000; width: 100vw; height: 100vh; max-height: none; margin: 0; border: none; border-radius: 0; box-shadow: none; }

/* Header */
.slls-lv-header { display: flex; align-items: center; gap: 12px; padding: 16px 20px; border-bottom: 1px solid var(--slls-border); flex-wrap: wrap; }
.slls-lv-headicon { display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 10px; background: var(--slls-accent-soft); color: var(--slls-accent); flex-shrink: 0; }
.slls-lv-titlewrap { display: flex; flex-direction: column; min-width: 0; }
.slls-lv-head-spacer { flex: 1 1 auto; }
.slls-lv-title { font-size: 20px; font-weight: 600; letter-spacing: -0.01em; line-height: 1.15; }
.slls-lv-subtitle { font-size: 12.5px; color: var(--slls-text-secondary); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 540px; }
.slls-lv-subtitle .slls-lv-sep { color: var(--slls-text-tertiary); margin: 0 6px; }
.slls-lv-subtitle b { color: var(--slls-text); font-weight: 500; }

.slls-lv-btn { appearance: none; border: 1px solid var(--slls-border-strong); background: var(--slls-surface); color: var(--slls-text); font-family: inherit; font-size: 13px; font-weight: 500; padding: 7px 14px; border-radius: 999px; cursor: pointer; display: inline-flex; align-items: center; gap: 7px; transition: background 120ms ease, border-color 120ms ease, transform 80ms ease, opacity 120ms ease; }
.slls-lv-btn:hover { background: var(--slls-surface-2); border-color: var(--slls-text-tertiary); }
.slls-lv-btn:active { transform: scale(0.97); }
.slls-lv-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.slls-lv-btn-primary { background: var(--slls-accent); border-color: var(--slls-accent); color: #fff; }
.slls-lv-btn-primary:hover { background: var(--slls-accent-hover); border-color: var(--slls-accent-hover); }
.slls-lv-btn-icon { width: 34px; height: 34px; padding: 0; justify-content: center; border-radius: 50%; }
.slls-lv-btn svg { display: block; }

/* Summary bar */
.slls-lv-summary { display: flex; flex-wrap: wrap; align-items: center; gap: 26px; padding: 10px 20px; border-bottom: 1px solid var(--slls-border); background: var(--slls-surface-2); }
.slls-lv-stat { display: flex; flex-direction: column; line-height: 1.15; }
.slls-lv-stat-label { font-size: 11px; color: var(--slls-text-secondary); }
.slls-lv-stat-value { font-size: 18px; font-weight: 600; font-variant-numeric: tabular-nums; }
.slls-lv-stat.bad .slls-lv-stat-value { color: var(--slls-danger); }
.slls-lv-stat.good .slls-lv-stat-value { color: var(--slls-success); }
.slls-lv-stat.warn .slls-lv-stat-value { color: var(--slls-warn); }
.slls-lv-summary-note { font-size: 12.5px; color: var(--slls-text-secondary); }

/* Body layout */
.slls-lv-body { display: flex; flex: 1; min-height: 0; }
.slls-lv-graphwrap { position: relative; flex: 1; min-width: 0; background: var(--slls-bg-secondary); }
.slls-lv-scroll { position: absolute; inset: 0; overflow: auto; cursor: grab; touch-action: none; }
.slls-lv-scroll.slls-lv-panning { cursor: grabbing; }
.slls-lv-canvas { position: relative; transform-origin: top left; }
.slls-lv-edges { position: absolute; inset: 0; pointer-events: none; }

/* Graph nodes */
.slls-lv-node { position: absolute; border-radius: 12px; border: 1.5px solid var(--slls-border-strong); background: var(--slls-bg-solid); box-shadow: var(--slls-shadow); padding: 10px 14px; cursor: move; user-select: none; display: flex; flex-direction: column; justify-content: center; gap: 3px; transition: box-shadow 120ms ease; }
.slls-lv-node.broken { border-color: var(--slls-danger); background: var(--slls-danger-soft); }
.slls-lv-node.clean { border-color: var(--slls-success); background: var(--slls-success-soft); }
.slls-lv-node.error { border-color: var(--slls-border-strong); background: var(--slls-surface); }
.slls-lv-node.selected { box-shadow: 0 0 0 2.5px var(--slls-accent); }
.slls-lv-node.picked { box-shadow: 0 0 0 2px var(--slls-accent-soft); }
.slls-lv-node-check { position: absolute; top: 8px; right: 8px; width: 15px; height: 15px; accent-color: var(--slls-accent); cursor: pointer; }
.slls-lv-node-name { font-size: 13px; font-weight: 600; line-height: 1.4; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding-right: 16px; }
/* Right-edge grip to resize node width; grows all nodes of the same type. */
.slls-lv-node-resize { position: absolute; top: 6px; bottom: 6px; right: -5px; width: 11px; cursor: ew-resize; z-index: 4; touch-action: none; border-radius: 6px; }
.slls-lv-node-resize::after { content: ""; position: absolute; top: 50%; right: 4px; width: 3px; height: 26px; transform: translateY(-50%); border-radius: 3px; background: transparent; transition: background 120ms ease; }
.slls-lv-node:hover .slls-lv-node-resize::after { background: var(--slls-border-strong); }
.slls-lv-node-resize:hover::after { background: var(--slls-accent); }
.slls-lv-node-ws { display: flex; align-items: center; gap: 5px; font-size: 11px; color: var(--slls-text-secondary); overflow: hidden; }
.slls-lv-node-ws span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-node-status { display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 500; }
.slls-lv-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
.slls-lv-node.broken .slls-lv-dot { background: var(--slls-danger); }
.slls-lv-node.clean .slls-lv-dot { background: var(--slls-success); }
.slls-lv-node.error .slls-lv-dot { background: var(--slls-text-tertiary); }
.slls-lv-node.broken .slls-lv-node-status { color: var(--slls-danger); }
.slls-lv-node.clean .slls-lv-node-status { color: var(--slls-success); }
.slls-lv-node.error .slls-lv-node-status { color: var(--slls-text-tertiary); }

.slls-lv-model { align-items: center; text-align: center; border-width: 2px; border-color: var(--slls-accent); background: var(--slls-accent-soft); }
.slls-lv-model-top { display: flex; align-items: center; gap: 7px; color: var(--slls-accent); font-size: 14px; font-weight: 700; line-height: 1.35; overflow: hidden; max-width: 100%; }
.slls-lv-model-top span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-model-ws { display: flex; align-items: center; gap: 5px; font-size: 11.5px; color: var(--slls-text-secondary); overflow: hidden; max-width: 100%; }
.slls-lv-model-ws span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-model-sub { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--slls-text-tertiary); }

/* Zoom controls */
.slls-lv-zoom { position: absolute; bottom: 16px; right: 16px; display: flex; flex-direction: column; align-items: center; gap: 4px; background: var(--slls-bg-solid); border: 1px solid var(--slls-border); border-radius: 10px; padding: 5px; box-shadow: var(--slls-shadow); }
.slls-lv-zoom button { width: 28px; height: 28px; border: none; background: transparent; color: var(--slls-text-secondary); border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
.slls-lv-zoom button:hover { background: var(--slls-surface-2); color: var(--slls-text); }
.slls-lv-zoom-label { font-size: 11px; font-weight: 600; color: var(--slls-text-secondary); font-variant-numeric: tabular-nums; cursor: pointer; border-radius: 5px; padding: 1px 5px; transition: background 120ms ease, color 120ms ease; }
.slls-lv-zoom-label:hover { background: var(--slls-surface-2); color: var(--slls-text); }
.slls-lv-zoom-input { width: 46px; text-align: center; font-size: 11px; font-weight: 600; font-variant-numeric: tabular-nums; color: var(--slls-text); background: var(--slls-bg-solid); border: 1px solid var(--slls-accent); border-radius: 5px; padding: 1px 2px; font-family: inherit; outline: none; box-shadow: 0 0 0 3px var(--slls-accent-soft); }

/* Center overlays (loading / empty / error) */
.slls-lv-center { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; padding: 24px; }
.slls-lv-center-inner { max-width: 380px; }
.slls-lv-center-inner .slls-lv-ic { color: var(--slls-text-tertiary); opacity: 0.6; }
.slls-lv-center-inner h4 { margin: 10px 0 4px; font-size: 15px; font-weight: 600; }
.slls-lv-center-inner p { margin: 0; font-size: 12.5px; color: var(--slls-text-secondary); }

/* Side panel */
.slls-lv-panel { position: relative; width: 360px; flex-shrink: 0; border-left: 1px solid var(--slls-border); display: flex; flex-direction: column; min-height: 0; background: var(--slls-bg-solid); }
.slls-lv-panel.slls-lv-panel-collapsed { width: 46px; min-width: 46px; }
/* Drag handle straddling the panel's left border to resize its width. */
.slls-lv-panel-resize { position: absolute; left: -4px; top: 0; bottom: 0; width: 8px; cursor: col-resize; z-index: 6; touch-action: none; }
.slls-lv-panel-resize::after { content: ""; position: absolute; left: 3px; top: 0; bottom: 0; width: 2px; background: transparent; transition: background 120ms ease; }
.slls-lv-panel-resize:hover::after, .slls-lv-panel-resize.slls-lv-resizing::after { background: var(--slls-accent); }
/* Collapsed rail */
.slls-lv-rail { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 12px 0; height: 100%; }
.slls-lv-rail-badge { font-size: 11px; font-weight: 600; padding: 2px 7px; border-radius: 999px; background: var(--slls-danger-soft); color: var(--slls-danger); font-variant-numeric: tabular-nums; }
.slls-lv-rail-label { writing-mode: vertical-rl; transform: rotate(180deg); font-size: 11.5px; font-weight: 600; letter-spacing: 0.04em; color: var(--slls-text-secondary); white-space: nowrap; }
.slls-lv-panel-head { display: flex; align-items: flex-start; gap: 10px; padding: 14px 16px; border-bottom: 1px solid var(--slls-border); }
.slls-lv-panel-head .slls-lv-ic { color: var(--slls-accent); margin-top: 1px; flex-shrink: 0; }
.slls-lv-panel-head .slls-lv-pt { min-width: 0; flex: 1; }
.slls-lv-panel-title { font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-panel-sub { font-size: 11.5px; color: var(--slls-text-secondary); margin-top: 2px; display: flex; align-items: center; gap: 5px; }
.slls-lv-panel-sub span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-panel-close { width: 28px; height: 28px; border: none; background: transparent; color: var(--slls-text-secondary); border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
.slls-lv-panel-close:hover { background: var(--slls-surface-2); color: var(--slls-text); }
.slls-lv-weblink { display: flex; align-items: center; gap: 6px; padding: 9px 16px; border-bottom: 1px solid var(--slls-border); font-size: 12px; color: var(--slls-accent); text-decoration: none; }
.slls-lv-weblink:hover { background: var(--slls-surface-2); }
.slls-lv-panel-btn { flex-shrink: 0; font-size: 12px; padding: 6px 12px; }
.slls-lv-panel-body { flex: 1; overflow-y: auto; padding: 10px 12px; min-height: 0; }
.slls-lv-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 8px; padding: 48px 16px; }
.slls-lv-empty .slls-lv-ic { opacity: 0.65; }
.slls-lv-empty.good .slls-lv-ic { color: var(--slls-success); opacity: 1; }
.slls-lv-empty h4 { margin: 0; font-size: 13.5px; font-weight: 600; }
.slls-lv-empty p { margin: 0; font-size: 12px; color: var(--slls-text-secondary); max-width: 260px; }

.slls-lv-repbtn { width: 100%; text-align: left; border: 1px solid var(--slls-border); background: var(--slls-surface); color: var(--slls-text); border-radius: 10px; padding: 10px 12px; margin-bottom: 8px; cursor: pointer; display: flex; align-items: center; gap: 10px; transition: background 120ms ease, border-color 120ms ease; }
.slls-lv-repbtn .slls-lv-ic { color: var(--slls-text-secondary); flex-shrink: 0; }
.slls-lv-repbtn:hover { background: var(--slls-surface-2); border-color: var(--slls-text-tertiary); }
.slls-lv-repbtn .slls-lv-rp { min-width: 0; flex: 1; }
.slls-lv-repbtn-name { font-size: 13px; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.slls-lv-repbtn-meta { font-size: 11.5px; color: var(--slls-danger); margin-top: 1px; }
.slls-lv-badge { flex-shrink: 0; font-size: 11px; font-weight: 600; padding: 2px 9px; border-radius: 999px; background: var(--slls-danger-soft); color: var(--slls-danger); font-variant-numeric: tabular-nums; }

.slls-lv-obj { border: 1px solid var(--slls-border); border-radius: 10px; padding: 9px 11px; margin-bottom: 7px; background: var(--slls-surface); }
.slls-lv-obj-name { font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; color: var(--slls-text); overflow-wrap: anywhere; }
.slls-lv-obj-meta { display: flex; align-items: center; gap: 6px; margin-top: 5px; }
.slls-lv-tag { font-size: 10.5px; font-weight: 500; padding: 1px 8px; border-radius: 999px; border: 1px solid var(--slls-border-strong); color: var(--slls-text-secondary); }
.slls-lv-tag.type { background: var(--slls-accent-soft); border-color: transparent; color: var(--slls-accent); }
.slls-lv-obj-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.slls-lv-fix { display: flex; align-items: center; gap: 8px; margin-top: 8px; }
.slls-lv-fix-select { flex: 1; padding-top: 6px; padding-bottom: 6px; font-size: 12.5px; }
.slls-lv-fix-arrow { color: var(--slls-success); display: inline-flex; flex-shrink: 0; }
.slls-lv-staged { flex: 1; font-size: 12.5px; color: var(--slls-text-secondary); overflow-wrap: anywhere; }
.slls-lv-unstage { width: 24px; height: 24px; border: none; background: transparent; color: var(--slls-text-tertiary); border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
.slls-lv-unstage:hover { background: var(--slls-surface-2); color: var(--slls-text); }
.slls-lv-fix-note { font-size: 11.5px; color: var(--slls-text-tertiary); font-style: italic; }
.slls-lv-panel-meta { font-size: 11.5px; color: var(--slls-text-secondary); margin-top: 3px; }
.slls-lv-section-label { font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--slls-text-tertiary); margin: 2px 2px 8px; }
.slls-lv-obj-main { display: flex; align-items: center; gap: 8px; min-width: 0; }
.slls-lv-obj-ic { display: inline-flex; color: var(--slls-text-secondary); flex-shrink: 0; }
.slls-lv-fix-ic { display: inline-flex; color: var(--slls-text-secondary); flex-shrink: 0; }
.slls-lv-fix-staged { border: 1px solid var(--slls-border-strong); background: var(--slls-surface-2); border-radius: 9px; padding: 7px 9px; }
.slls-lv-combo { position: relative; flex: 1; min-width: 0; }
.slls-lv-combo-input { width: 100%; background: var(--slls-surface); border: 1px solid var(--slls-border-strong); border-radius: 10px; padding: 7px 12px; font-size: 12.5px; color: var(--slls-text); font-family: inherit; }
.slls-lv-combo-input:focus { outline: none; border-color: var(--slls-accent); box-shadow: 0 0 0 3px var(--slls-accent-soft); }
.slls-lv-combo-input::placeholder { color: var(--slls-text-tertiary); }
.slls-lv-combo-list { position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 30; max-height: 220px; overflow-y: auto; background: var(--slls-bg-solid); border: 1px solid var(--slls-border-strong); border-radius: 10px; box-shadow: var(--slls-shadow); padding: 4px; }
.slls-lv-combo-item { padding: 6px 10px; border-radius: 7px; font-size: 12px; color: var(--slls-text); cursor: pointer; font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.slls-lv-combo-item:hover { background: var(--slls-accent-soft); color: var(--slls-accent); }
.slls-lv-combo-empty { padding: 8px 10px; font-size: 12px; color: var(--slls-text-tertiary); }

/* Status toast */
.slls-lv-status { padding: 9px 20px; font-size: 12.5px; border-top: 1px solid var(--slls-border); }
.slls-lv-status.success { background: var(--slls-success-soft); color: var(--slls-success); }
.slls-lv-status.error { background: var(--slls-danger-soft); color: var(--slls-danger); }
.slls-lv-status.info { background: var(--slls-surface-2); color: var(--slls-text-secondary); }

/* Footer */
.slls-lv-footer { padding: 8px 20px; border-top: 1px solid var(--slls-border); text-align: right; font-size: 11.5px; color: var(--slls-text-tertiary); }
.slls-lv-footer a { color: var(--slls-text-tertiary); text-decoration: none; transition: color 120ms ease; }
.slls-lv-footer a:hover { color: var(--slls-accent); }

/* Rebind modal */
.slls-lv-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.35); display: flex; align-items: center; justify-content: center; z-index: 40; }
.slls-lv-modal { width: 420px; max-width: calc(100% - 40px); background: var(--slls-bg-solid); border: 1px solid var(--slls-border); border-radius: var(--slls-radius); box-shadow: 0 20px 60px rgba(0,0,0,0.35); padding: 20px; }
.slls-lv-modal h3 { margin: 0 0 4px; font-size: 16px; font-weight: 600; }
.slls-lv-modal p { margin: 0 0 16px; font-size: 12.5px; color: var(--slls-text-secondary); }
.slls-lv-field { display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px; }
.slls-lv-field label { font-size: 12px; color: var(--slls-text-secondary); padding-left: 8px; }
.slls-lv-select { appearance: none; -webkit-appearance: none; width: 100%; background: var(--slls-surface); border: 1px solid var(--slls-border-strong); border-radius: 10px; padding: 8px 32px 8px 12px; font-size: 13px; color: var(--slls-text); font-family: inherit; cursor: pointer; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='%236e6e73' d='M0 0l5 6 5-6z'/></svg>"); background-repeat: no-repeat; background-position: right 12px center; text-overflow: ellipsis; }
.slls-lv-select:focus { outline: none; border-color: var(--slls-accent); box-shadow: 0 0 0 3px var(--slls-accent-soft); }
.slls-lv-select option { background: #ffffff; color: #1d1d1f; }
.slls-lv.slls-lv-dark .slls-lv-select option { background: #2c2c2e; color: #f5f5f7; }
@media (prefers-color-scheme: dark) { .slls-lv.slls-lv-auto .slls-lv-select option { background: #2c2c2e; color: #f5f5f7; } }
.slls-lv-modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }

/* Model / workspace picker ("connect" screen) */
.slls-lv-picker-wrap { display: flex; align-items: flex-start; justify-content: stretch; padding: 0 24px 24px; overflow: auto; }
.slls-lv-graphwrap.slls-lv-picker-wrap { background: var(--slls-bg-solid); }
.slls-lv-picker { width: 100%; background: var(--slls-surface); border: 1px solid var(--slls-border); border-radius: 14px; padding: 16px; }
.slls-lv-picker-top { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 14px; }
.slls-lv-picker-head { min-width: 0; }
.slls-lv-picker-title { font-size: 14px; font-weight: 600; }
.slls-lv-picker-sub { font-size: 12.5px; color: var(--slls-text-secondary); margin-top: 3px; }
.slls-lv-picker-grid { display: flex; align-items: flex-end; gap: 10px; flex-wrap: wrap; }
.slls-lv-picker-grid .slls-lv-field { flex: 1 1 240px; margin-bottom: 0; }
.slls-lv-picker-grid .slls-lv-field label { padding-left: 4px; color: var(--slls-text-tertiary); font-size: 11px; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase; }
.slls-lv-picker-grid .slls-ss-btn { border-radius: 999px; padding: 7px 12px 7px 15px; background: var(--slls-surface); font-size: 13.5px; }
.slls-lv-picker-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 14px; }
.slls-lv-modal .slls-lv-field label { padding-left: 4px; color: var(--slls-text-tertiary); font-size: 11px; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase; }
.slls-lv-modal .slls-ss-btn { background: var(--slls-surface); font-size: 13px; padding: 8px 12px; }
@media (max-width: 640px) {
    .slls-lv-picker-wrap { padding: 0 16px 16px; }
    .slls-lv-picker-grid { align-items: stretch; flex-direction: column; }
}

.slls-lv-spin { animation: slls-lv-spin 0.8s linear infinite; transform-origin: center; }
@keyframes slls-lv-spin { to { transform: rotate(360deg); } }
.slls-lv-scroll::-webkit-scrollbar, .slls-lv-panel-body::-webkit-scrollbar { width: 10px; height: 10px; }
.slls-lv-scroll::-webkit-scrollbar-thumb, .slls-lv-panel-body::-webkit-scrollbar-thumb { background: var(--slls-border-strong); border-radius: 999px; background-clip: padding-box; border: 2px solid transparent; }
"""


# ---------------------------------------------------------------------------
# Widget JS (anywidget ESM). Icons injected via __ICON_*__ placeholders below.
# ---------------------------------------------------------------------------
_WIDGET_JS = r"""
function render({ model, el }) {
    const ICON = {
        database: `__ICON_DATABASE__`, report: `__ICON_REPORT__`,
        refresh: `__ICON_REFRESH__`, scan: `__ICON_SCAN__`, link: `__ICON_LINK__`,
        check: `__ICON_CHECK__`, alert: `__ICON_ALERT__`, external: `__ICON_EXTERNAL__`,
        zoomin: `__ICON_ZOOMIN__`, zoomout: `__ICON_ZOOMOUT__`, close: `__ICON_CLOSE__`,
        workflow: `__ICON_WORKFLOW__`, sun: `__ICON_SUN__`, moon: `__ICON_MOON__`,
        fullscreen: `__ICON_FULLSCREEN__`, fullscreen_exit: `__ICON_FULLSCREEN_EXIT__`,
        measure: `__ICON_MEASURE__`, column: `__ICON_COLUMN__`, hierarchy: `__ICON_HIERARCHY__`,
        save: `__ICON_SAVE__`, wrench: `__ICON_WRENCH__`, undo: `__ICON_UNDO__`,
        chevron_left: `__ICON_CHEVRON_LEFT__`, chevron_right: `__ICON_CHEVRON_RIGHT__`,
        swap: `__ICON_SWAP__`,
    };

    const MODEL_KEY = "__model__";
    const NODE_H = 86, CENTER_H = 92, MARGIN = 150;
    // Node widths are sized dynamically to fit the longest report / model name
    // (see computeNodeWidths). They start at their historical defaults so the
    // first layout pass has sane values before any measurement runs.
    let NODE_W = 184, CENTER_W = 204;
    const MIN_ZOOM = 0.3, MAX_ZOOM = 2.5;

    const root = document.createElement("div");
    root.className = "slls-lv";
    el.appendChild(root);

    function applyTheme() {
        root.classList.remove("slls-lv-dark", "slls-lv-auto");
        const dm = model.get("dark_mode");
        if (dm === true) root.classList.add("slls-lv-dark");
        else if (dm == null) root.classList.add("slls-lv-auto");
    }
    applyTheme();
    model.on("change:dark_mode", applyTheme);

    // --- Fullscreen ---
    // Notebook hosts (VS Code, Jupyter, Fabric) frequently sandbox the widget
    // output, so the native Fullscreen API silently rejects. We therefore drive
    // a CSS overlay that covers the viewport as the reliable primary mechanism,
    // and additionally attempt native fullscreen as a best-effort enhancement.
    let fsMode = false;
    function isFullscreen() { return fsMode; }
    function nativeExit() {
        const ex = document.exitFullscreen || document.webkitExitFullscreen;
        if (ex && (document.fullscreenElement || document.webkitFullscreenElement)) {
            const p = ex.call(document);
            if (p && p.catch) p.catch(() => {});
        }
    }
    function setFullscreen(on) {
        fsMode = on;
        root.classList.toggle("slls-lv-fs", on);
        try {
            if (on) {
                const req = root.requestFullscreen || root.webkitRequestFullscreen;
                if (req) { const p = req.call(root); if (p && p.catch) p.catch(() => {}); }
            } else {
                nativeExit();
            }
        } catch (e) { /* native fullscreen unavailable; CSS overlay covers it */ }
        renderAll();
    }
    function toggleFullscreen() { setFullscreen(!fsMode); }
    function onFullscreenChange() {
        // Fires only when native fullscreen state changes; if the user left it
        // (Esc / F11), drop the CSS overlay too.
        const nativeOn = !!(document.fullscreenElement || document.webkitFullscreenElement);
        if (!nativeOn && fsMode) { fsMode = false; root.classList.remove("slls-lv-fs"); renderAll(); }
    }
    function onEscKey(e) {
        if (e.key === "Escape" && fsMode) setFullscreen(false);
    }
    document.addEventListener("fullscreenchange", onFullscreenChange);
    document.addEventListener("webkitfullscreenchange", onFullscreenChange);
    document.addEventListener("keydown", onEscKey);

    // --- Local UI state ---
    let selectedId = null;
    let picked = new Set();          // report ids checked for rebind
    let stagedFixes = new Map();     // fixKey -> staged fix payload
    let zoom = 1;
    let positions = {};              // key -> {x, y}
    let positionsKey = "";
    let rebindOpen = false;
    let rebindWs = "";
    let rebindDs = "";
    let workspacesRequested = (model.get("workspaces") || []).length > 1;  // full tenant workspace list fetched once
    // Model/workspace picker ("connect" screen). Shown whenever no model is
    // connected, or when the user reopens it to switch models.
    let pickerReopen = false;
    let pickWs = "";
    let pickDs = "";
    let panelWidth = 360;             // side panel width (px)
    let panelCollapsed = false;       // side panel collapsed to a thin rail
    // User-set node widths (px). null = auto-fit to the longest name. Set by
    // dragging a node's right-edge grip; report nodes stay uniform, the model
    // (center) node is sized independently.
    let nodeWOverride = null;
    let centerWOverride = null;
    // Preserved graph scroll offset. viewKey tracks the layout+zoom the view
    // was last centred for, so re-renders that don't change either (e.g.
    // toggling a report checkbox) keep the user's current position.
    let viewKey = "";
    let viewport = null;
    const PANEL_MIN = 280, PANEL_MAX = 720;

    const esc = (s) => String(s == null ? "" : s)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

    const reports = () => model.get("reports") || [];
    const analyzed = () => !!model.get("analyzed");
    const busy = () => !!model.get("busy");
    const connected = () => !!model.get("connected");
    // The picker screen replaces the graph whenever no model is connected or
    // the user has explicitly reopened it to switch models.
    const showPicker = () => !connected() || pickerReopen;
    // Front-end-local "working" flag: flipped on the instant a button is
    // clicked so the UI reacts immediately, without waiting for the back-end
    // round-trip to set the synced "busy" trait. Cleared once the back-end
    // reports a result (see the model change wiring below).
    let busyLocal = false;
    const working = () => busyLocal || busy();
    const modelObjects = () => model.get("model_objects") || [];
    const health = (r) => (!r.analyzed ? "error" : (r.invalidCount > 0 ? "broken" : "clean"));
    const fixKey = (rid, type, table, name, hierarchy) =>
        `${rid}\u0000${type}\u0000${table}\u0000${hierarchy || ""}\u0000${name}`;
    // Measures are model-global, so they are shown without a table prefix or
    // square brackets; columns/hierarchies keep the 'Table'[Object] form; a
    // hierarchy level is shown as 'Table'[Hierarchy].[Level].
    const objLabel = (type, table, name, hierarchy) =>
        type === "Measure" ? `${name}`
        : type === "Hierarchy Level" ? `'${table}'[${hierarchy}].[${name}]`
        : `'${table}'[${name}]`;
    const typeIcon = (type) =>
        type === "Measure" ? ICON.measure
        : type === "Column" ? ICON.column
        : (type === "Hierarchy" || type === "Hierarchy Level") ? ICON.hierarchy
        : ICON.report;

    function dispatch(payload) {
        // Reflect activity immediately for snappy feedback, then re-render so
        // the clicked button shows its working state before the round-trip
        // completes.
        busyLocal = true;
        model.set("pending_action", payload);
        // Guard against an undefined "run" (some notebook hosts do not seed
        // every synced trait into the front-end model): "undefined + 1" is NaN,
        // which serializes to JSON null and makes the back-end set_state raise a
        // TraitError before the observer fires, so the click silently does
        // nothing. Coercing to 0 keeps the counter a valid integer.
        model.set("run", (model.get("run") || 0) + 1);
        model.save_changes();
        renderAll();
    }

    function saveFixes() {
        if (stagedFixes.size === 0) return;
        dispatch({ action: "save_fixes", fixes: [...stagedFixes.values()] });
    }

    // Font stack shared with the CSS so off-screen text measurement matches
    // what the browser actually renders.
    const NODE_FONT_FAMILY = '-apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Helvetica Neue", Helvetica, Arial, sans-serif';
    const _measureCtx = document.createElement("canvas").getContext("2d");
    function textWidth(text, font) {
        _measureCtx.font = font + " " + NODE_FONT_FAMILY;
        return _measureCtx.measureText(String(text == null ? "" : text)).width;
    }

    // Size the report / model node widths so their full name and workspace row
    // fit inside the panel instead of spilling past the rounded border. Widths
    // are clamped so a single very long name cannot make the graph unwieldy;
    // beyond the cap the CSS ellipsis takes over.
    function computeNodeWidths() {
        const HPAD = 28;         // node left + right padding (14px each)
        const ICON_GAP = 16 + 5; // workspace-row icon width + gap
        const CHECK_PAD = 16;    // report name reserves room for the checkbox
        const MINW = 184, MAXW = 340;

        let need = MINW;
        for (const r of reports()) {
            const nameW = textWidth(r.name, "600 13px") + CHECK_PAD;
            const wsW = ICON_GAP + textWidth(r.workspaceName, "11px");
            need = Math.max(need, nameW, wsW);
        }
        NODE_W = nodeWOverride != null
            ? nodeWOverride
            : Math.min(MAXW, Math.ceil(need + HPAD));

        let cneed = 204;
        const mTopW = 16 + 7 + textWidth(model.get("dataset_name"), "700 14px");
        const mWsW = ICON_GAP + textWidth(model.get("workspace_name"), "11.5px");
        cneed = Math.max(cneed, mTopW, mWsW);
        CENTER_W = centerWOverride != null
            ? centerWOverride
            : Math.min(MAXW + 40, Math.ceil(cneed + HPAD));
    }

    function computePositions() {
        const rs = reports();
        const n = rs.length;
        const radius = Math.max(240, (n * (NODE_W + 48)) / (2 * Math.PI));
        const cx = radius + CENTER_W + MARGIN;
        const cy = radius + CENTER_H + MARGIN;
        const pos = {};
        pos[MODEL_KEY] = { x: cx, y: cy };
        rs.forEach((r, i) => {
            const a = -Math.PI / 2 + (i / Math.max(1, n)) * Math.PI * 2;
            pos[r.id] = { x: cx + radius * Math.cos(a), y: cy + radius * Math.sin(a) };
        });
        return pos;
    }

    function syncPositions() {
        const key = reports().map((r) => r.id).join("\u0000");
        if (key !== positionsKey) {
            computeNodeWidths();
            positions = computePositions();
            positionsKey = key;
        }
    }

    function canvasSize() {
        let maxX = 900, maxY = 640;
        for (const k of Object.keys(positions)) {
            const p = positions[k];
            maxX = Math.max(maxX, p.x + NODE_W);
            maxY = Math.max(maxY, p.y + NODE_H);
        }
        return { w: maxX + MARGIN, h: maxY + MARGIN };
    }

    // Border point of a rect (centre cx,cy; half hw,hh) toward (tx,ty).
    function edgePoint(cx, cy, tx, ty, hw, hh) {
        const dx = tx - cx, dy = ty - cy;
        if (dx === 0 && dy === 0) return { x: cx, y: cy };
        const scale = 1 / Math.max(Math.abs(dx) / hw, Math.abs(dy) / hh);
        return { x: cx + dx * scale, y: cy + dy * scale };
    }

    function icon(name, cls) {
        return `<span class="slls-lv-ic ${cls || ""}">${ICON[name] || ""}</span>`;
    }

    // ---------- Rendering ----------
    function renderAll() {
        syncPositions();
        root.innerHTML = "";
        root.appendChild(buildHeader());
        if (showPicker()) {
            root.appendChild(buildPickerScreen());
        } else {
            root.appendChild(buildSummary());
            root.appendChild(buildBody());
        }
        const st = model.get("status") || {};
        if (st.message) {
            const s = document.createElement("div");
            s.className = "slls-lv-status " + (st.kind || "info");
            s.textContent = st.message;
            root.appendChild(s);
        }
        root.appendChild(buildFooter());
        if (rebindOpen) root.appendChild(buildRebindModal());
        attachGraphInteractions();
    }

    function buildHeader() {
        const h = document.createElement("div");
        h.className = "slls-lv-header";
        const dm = model.get("dark_mode") === true;
        const nPick = picked.size;
        const picking = showPicker();
        const dsName = model.get("dataset_name");
        const subtitle = connected() && dsName
            ? `<b>${esc(dsName)}</b><span class="slls-lv-sep">&middot;</span>${esc(model.get("workspace_name"))}`
            : `Select a semantic model to evaluate`;
        h.innerHTML =
            `<span class="slls-lv-headicon">${ICON.workflow}</span>` +
            `<div class="slls-lv-titlewrap">` +
                `<div class="slls-lv-title">Lineage view</div>` +
                `<div class="slls-lv-subtitle">${subtitle}</div>` +
            `</div>` +
            (connected() && !picking
                ? `<button class="sl-change-btn" data-act="change-model" title="Change semantic model / workspace">${ICON.swap}</button>`
                : "") +
            `<div class="slls-lv-head-spacer"></div>` +
            (!picking && stagedFixes.size > 0
                ? `<button class="slls-lv-btn slls-lv-btn-primary slls-lv-btn-icon" data-act="save" title="Save ${stagedFixes.size} staged fix${stagedFixes.size === 1 ? "" : "es"}" ${working() ? "disabled" : ""}>` +
                    `${working() ? spinner() : ICON.save}</button>`
                : "") +
            (!picking && nPick > 0
                ? `<button class="slls-lv-btn" data-act="open-rebind">${ICON.link}Rebind ${nPick}</button>`
                : "") +
            (!picking
                ? `<button class="sl-reload-btn" data-act="refresh" title="Reload downstream reports" ${working() ? "disabled" : ""}>` +
                    `${working() ? spinner() : ICON.refresh}</button>`
                : "") +
            `<button class="sl-theme-btn" data-act="fullscreen" title="Toggle full screen">${isFullscreen() ? ICON.fullscreen_exit : ICON.fullscreen}</button>` +
            `<button class="sl-theme-btn" data-act="theme" title="Toggle theme">${dm ? ICON.sun : ICON.moon}</button>`;

        const rf = h.querySelector('[data-act="refresh"]');
        if (rf) rf.onclick = () => dispatch({ action: "refresh" });
        h.querySelector('[data-act="fullscreen"]').onclick = () => toggleFullscreen();
        h.querySelector('[data-act="theme"]').onclick = () => {
            model.set("dark_mode", !(model.get("dark_mode") === true));
            model.save_changes();
            renderAll();
        };
        const rb = h.querySelector('[data-act="open-rebind"]');
        if (rb) rb.onclick = () => openRebind();
        const cm = h.querySelector('[data-act="change-model"]');
        if (cm) cm.onclick = () => openPicker();
        const sv = h.querySelector('[data-act="save"]');
        if (sv) sv.onclick = () => saveFixes();
        return h;
    }

    function spinner() {
        return `<span class="slls-lv-ic"><svg class="slls-lv-spin" width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M8 1.6a6.4 6.4 0 1 1-6.4 6.4" opacity="0.85"/></svg></span>`;
    }

    function buildSummary() {
        const s = document.createElement("div");
        s.className = "slls-lv-summary";
        const rs = reports();
        const broken = rs.filter((r) => health(r) === "broken").length;
        const errored = rs.filter((r) => health(r) === "error").length;
        const brokenObjs = rs.reduce((n, r) => n + (r.invalidCount || 0), 0);
        let html = stat("Downstream reports", rs.length, "");
        if (analyzed()) {
            html += stat("Reports with broken elements", broken, broken > 0 ? "bad" : "good");
            html += stat("Broken objects", brokenObjs, brokenObjs > 0 ? "bad" : "good");
            if (errored > 0) html += stat("Not analyzed", errored, "warn");
        } else {
            html += `<span class="slls-lv-summary-note">Broken elements not analyzed yet &mdash; use &ldquo;Analyze broken elements&rdquo;.</span>`;
        }
        s.innerHTML = html;
        return s;
    }

    function stat(label, value, tone) {
        return `<div class="slls-lv-stat ${tone}"><span class="slls-lv-stat-label">${esc(label)}</span>` +
            `<span class="slls-lv-stat-value">${value}</span></div>`;
    }

    function buildBody() {
        const body = document.createElement("div");
        body.className = "slls-lv-body";
        body.appendChild(buildGraph());
        const rs = reports();
        if (rs.length > 0) body.appendChild(buildPanel());
        return body;
    }

    function buildGraph() {
        const wrap = document.createElement("div");
        wrap.className = "slls-lv-graphwrap";
        const rs = reports();

        if (busy() && rs.length === 0) {
            wrap.innerHTML = centerMsg("scan", "Loading downstream reports\u2026", "");
            return wrap;
        }
        if (rs.length === 0) {
            wrap.innerHTML = centerMsg("report", "No downstream reports",
                "No reports in this workspace consume this semantic model.");
            return wrap;
        }

        const size = canvasSize();
        const scroll = document.createElement("div");
        scroll.className = "slls-lv-scroll";
        const canvas = document.createElement("div");
        canvas.className = "slls-lv-canvas";
        canvas.style.width = size.w + "px";
        canvas.style.height = size.h + "px";
        canvas.style.transform = `scale(${zoom})`;

        // Edges
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("class", "slls-lv-edges");
        svg.setAttribute("width", size.w);
        svg.setAttribute("height", size.h);
        const m = positions[MODEL_KEY];
        rs.forEach((r) => {
            const p = positions[r.id];
            if (!p) return;
            const a = edgePoint(m.x, m.y, p.x, p.y, CENTER_W / 2, CENTER_H / 2);
            const b = edgePoint(p.x, p.y, m.x, m.y, NODE_W / 2, NODE_H / 2);
            const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
            line.setAttribute("id", "slls-lv-edge-" + r.id);
            line.setAttribute("x1", a.x); line.setAttribute("y1", a.y);
            line.setAttribute("x2", b.x); line.setAttribute("y2", b.y);
            const hs = health(r);
            const col = selectedId === r.id ? "var(--slls-accent)"
                : hs === "broken" ? "var(--slls-danger)"
                : hs === "clean" ? "var(--slls-success)" : "var(--slls-border-strong)";
            line.setAttribute("stroke", col);
            line.setAttribute("stroke-width", selectedId === r.id ? "2.4" : "1.5");
            svg.appendChild(line);
        });
        canvas.appendChild(svg);

        // Model node
        canvas.appendChild(buildModelNode());
        // Report nodes
        rs.forEach((r) => canvas.appendChild(buildReportNode(r)));

        scroll.appendChild(canvas);

        // Click-and-drag panning on empty canvas space. Nodes call
        // stopPropagation on pointerdown, so dragging a node never pans.
        const startPan = (e) => {
            if (e.button != null && e.button !== 0) return;
            e.preventDefault();
            const sx = e.clientX, sy = e.clientY;
            const sl = scroll.scrollLeft, stp = scroll.scrollTop;
            let moved = false;
            scroll.classList.add("slls-lv-panning");
            const move = (ev) => {
                if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 4) moved = true;
                scroll.scrollLeft = sl - (ev.clientX - sx);
                scroll.scrollTop = stp - (ev.clientY - sy);
            };
            const up = () => {
                window.removeEventListener("pointermove", move);
                window.removeEventListener("pointerup", up);
                scroll.classList.remove("slls-lv-panning");
                document.body.style.userSelect = "";
                // A click on empty canvas (i.e. not a drag/pan, and not on a
                // node since nodes stop propagation) deselects the report.
                if (!moved && selectedId !== null) {
                    selectedId = null;
                    renderAll();
                }
            };
            window.addEventListener("pointermove", move);
            window.addEventListener("pointerup", up);
            document.body.style.userSelect = "none";
        };
        scroll.addEventListener("pointerdown", startPan);
        canvas.addEventListener("pointerdown", startPan);

        // Remember the scroll offset so re-renders (e.g. toggling a report
        // checkbox or selecting a node) can restore the user's current view.
        scroll.addEventListener("scroll", () => {
            viewport = { left: scroll.scrollLeft, top: scroll.scrollTop };
        });

        wrap.appendChild(scroll);
        wrap.appendChild(buildZoom());

        // Only recentre on the model node when the layout or zoom actually
        // changed; otherwise restore the previous offset so the diagram stays
        // put across incidental re-renders.
        const centerKey = positionsKey + "|" + zoom;
        requestAnimationFrame(() => {
            if (viewKey !== centerKey || viewport === null) {
                scroll.scrollLeft = m.x * zoom - scroll.clientWidth / 2;
                scroll.scrollTop = m.y * zoom - scroll.clientHeight / 2;
                viewKey = centerKey;
            } else {
                scroll.scrollLeft = viewport.left;
                scroll.scrollTop = viewport.top;
            }
            viewport = { left: scroll.scrollLeft, top: scroll.scrollTop };
        });
        return wrap;
    }

    function centerMsg(ic, title, sub) {
        return `<div class="slls-lv-center"><div class="slls-lv-center-inner">` +
            `<span class="slls-lv-ic">${ICON[ic] || ""}</span>` +
            `<h4>${esc(title)}</h4>${sub ? `<p>${esc(sub)}</p>` : ""}</div></div>`;
    }

    function buildModelNode() {
        const p = positions[MODEL_KEY];
        const node = document.createElement("div");
        node.className = "slls-lv-node slls-lv-model";
        node.id = "slls-lv-node-" + MODEL_KEY;
        node.style.width = CENTER_W + "px";
        node.style.height = CENTER_H + "px";
        node.style.left = (p.x - CENTER_W / 2) + "px";
        node.style.top = (p.y - CENTER_H / 2) + "px";
        node.innerHTML =
            `<div class="slls-lv-model-top">${ICON.database}<span>${esc(model.get("dataset_name"))}</span></div>` +
            `<div class="slls-lv-model-ws">${ICON.workflow}<span>${esc(model.get("workspace_name"))}</span></div>` +
            `<div class="slls-lv-model-sub">Semantic model</div>`;
        node.addEventListener("pointerdown", (e) => startDrag(e, MODEL_KEY));
        node.appendChild(makeResizeGrip(true));
        return node;
    }

    function buildReportNode(r) {
        const p = positions[r.id];
        const hs = health(r);
        const node = document.createElement("div");
        node.className = "slls-lv-node " + hs +
            (selectedId === r.id ? " selected" : "") +
            (picked.has(r.id) && selectedId !== r.id ? " picked" : "");
        node.id = "slls-lv-node-" + r.id;
        node.style.width = NODE_W + "px";
        node.style.height = NODE_H + "px";
        node.style.left = (p.x - NODE_W / 2) + "px";
        node.style.top = (p.y - NODE_H / 2) + "px";
        const label = hs === "broken" ? `${r.invalidCount} broken`
            : hs === "clean" ? "No issues" : "Not analyzed";
        node.innerHTML =
            `<input type="checkbox" class="slls-lv-node-check" ${picked.has(r.id) ? "checked" : ""}>` +
            `<div class="slls-lv-node-name">${esc(r.name)}</div>` +
            `<div class="slls-lv-node-ws">${ICON.report}<span>${esc(r.workspaceName)}</span></div>` +
            `<div class="slls-lv-node-status"><span class="slls-lv-dot"></span>${esc(label)}</div>`;

        const chk = node.querySelector(".slls-lv-node-check");
        chk.addEventListener("pointerdown", (e) => e.stopPropagation());
        chk.addEventListener("click", (e) => {
            e.stopPropagation();
            if (chk.checked) picked.add(r.id); else picked.delete(r.id);
            renderAll();
        });
        node.appendChild(makeResizeGrip(false));
        node.addEventListener("pointerdown", (e) => startDrag(e, r.id));
        node.addEventListener("click", () => {
            if (dragMoved) { dragMoved = false; return; }
            selectedId = selectedId === r.id ? null : r.id;
            renderAll();
        });
        return node;
    }

    function buildZoom() {
        const z = document.createElement("div");
        z.className = "slls-lv-zoom";
        z.innerHTML =
            `<button data-z="in" title="Zoom in">${ICON.zoomin}</button>` +
            `<span class="slls-lv-zoom-label" data-z="label" role="button" tabindex="0" title="Click to set zoom level">${Math.round(zoom * 100)}%</span>` +
            `<button data-z="out" title="Zoom out">${ICON.zoomout}</button>`;
        z.querySelector('[data-z="in"]').onclick = () => setZoom(zoom * 1.2);
        z.querySelector('[data-z="out"]').onclick = () => setZoom(zoom / 1.2);
        const label = z.querySelector('[data-z="label"]');
        // The label doubles as a button: click (or keyboard-activate) to type
        // an exact zoom percentage.
        label.onclick = () => startEditZoom(label);
        label.onkeydown = (e) => {
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); startEditZoom(label); }
        };
        label.addEventListener("pointerdown", (e) => e.stopPropagation());
        return z;
    }

    // Replace the zoom label with an inline input so the user can type an
    // exact percentage. setZoom() clamps the value and re-renders, which
    // restores the label; an invalid entry simply re-renders unchanged.
    function startEditZoom(label) {
        const input = document.createElement("input");
        input.type = "text";
        input.className = "slls-lv-zoom-input";
        input.value = String(Math.round(zoom * 100));
        input.setAttribute("aria-label", "Zoom percentage");
        label.replaceWith(input);
        input.focus();
        input.select();
        input.addEventListener("pointerdown", (e) => e.stopPropagation());
        let done = false;
        const commit = (apply) => {
            if (done) return;
            done = true;
            const v = parseFloat(String(input.value).replace("%", "").trim());
            if (apply && !isNaN(v) && v > 0) setZoom(v / 100);
            else renderAll();
        };
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") { e.preventDefault(); commit(true); }
            else if (e.key === "Escape") { e.preventDefault(); commit(false); }
        });
        input.addEventListener("blur", () => commit(true));
    }

    function setZoom(v) {
        zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(v * 100) / 100));
        renderAll();
    }

    // ---------- Side panel ----------
    function buildPanel() {
        const panel = document.createElement("div");
        panel.className = "slls-lv-panel";
        if (panelCollapsed) {
            panel.classList.add("slls-lv-panel-collapsed");
            panel.appendChild(buildPanelRail());
            return panel;
        }
        panel.style.width = panelWidth + "px";
        const handle = document.createElement("div");
        handle.className = "slls-lv-panel-resize";
        handle.title = "Drag to resize";
        handle.addEventListener("pointerdown", startPanelResize);
        panel.appendChild(handle);
        const rep = reports().find((r) => r.id === selectedId) || null;
        if (rep) buildReportDetail(panel, rep);
        else buildBrokenSummary(panel);
        return panel;
    }

    // Thin rail shown when the panel is collapsed; click to expand.
    function buildPanelRail() {
        const rail = document.createElement("div");
        rail.className = "slls-lv-rail";
        const broken = reports().reduce((n, r) => n + (r.invalidCount || 0), 0);
        rail.innerHTML =
            `<button class="slls-lv-panel-close" data-act="expand" title="Expand panel">${ICON.chevron_left}</button>` +
            (analyzed() && broken > 0 ? `<span class="slls-lv-rail-badge">${broken}</span>` : "") +
            `<span class="slls-lv-rail-label">Broken elements</span>`;
        rail.querySelector('[data-act="expand"]').onclick = () => {
            panelCollapsed = false; renderAll();
        };
        return rail;
    }

    // Collapse toggle placed in each panel head.
    function collapseBtn() {
        return `<button class="slls-lv-panel-close" data-act="collapse" title="Collapse panel">${ICON.chevron_right}</button>`;
    }

    function startPanelResize(e) {
        if (e.button != null && e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        const startX = e.clientX;
        const startW = panelWidth;
        const handle = e.currentTarget;
        const panel = handle.parentElement;
        handle.classList.add("slls-lv-resizing");
        const move = (ev) => {
            // Panel sits on the right, so dragging left widens it.
            const w = startW - (ev.clientX - startX);
            panelWidth = Math.max(PANEL_MIN, Math.min(PANEL_MAX, w));
            if (panel) panel.style.width = panelWidth + "px";
        };
        const up = () => {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
            handle.classList.remove("slls-lv-resizing");
            document.body.style.userSelect = "";
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
        document.body.style.userSelect = "none";
    }

    function buildBrokenSummary(panel) {
        const head = document.createElement("div");
        head.className = "slls-lv-panel-head";
        head.innerHTML =
            `<span class="slls-lv-ic">${ICON.scan}</span>` +
            `<div class="slls-lv-pt"><div class="slls-lv-panel-title">Broken elements summary</div>` +
            `<div class="slls-lv-panel-sub"><span>${analyzed()
                ? "Select a report to see its broken elements."
                : "Analyze the reports to check for broken elements."}</span></div></div>` +
            `<button class="slls-lv-btn slls-lv-btn-primary slls-lv-panel-btn" data-act="panel-analyze" ${working() ? "disabled" : ""}>` +
            `${ICON.scan}${analyzed() ? "Re-analyze" : "Analyze"}${working() ? spinner() : ""}</button>` +
            collapseBtn();
        head.querySelector('[data-act="panel-analyze"]').onclick = () =>
            dispatch({ action: "analyze" });
        head.querySelector('[data-act="collapse"]').onclick = () => {
            panelCollapsed = true; renderAll();
        };
        panel.appendChild(head);

        const bodyEl = document.createElement("div");
        bodyEl.className = "slls-lv-panel-body";
        const rs = reports();
        const brokenReports = rs.filter((r) => health(r) === "broken");
        if (!analyzed()) {
            bodyEl.innerHTML = emptyState("scan", "Not analyzed yet",
                "Broken elements are not calculated automatically. Use the \u201CAnalyze broken elements\u201D button to check each report.", false);
        } else if (brokenReports.length === 0) {
            bodyEl.innerHTML = emptyState("check", "All reports are healthy",
                "Every downstream report only references objects that exist in the model.", true);
        } else {
            brokenReports.forEach((r) => {
                const b = document.createElement("button");
                b.className = "slls-lv-repbtn";
                b.innerHTML =
                    `<span class="slls-lv-ic">${ICON.report}</span>` +
                    `<span class="slls-lv-rp"><span class="slls-lv-repbtn-name">${esc(r.name)}</span></span>` +
                    `<span class="slls-lv-badge">${r.invalidCount}</span>`;
                b.onclick = () => { selectedId = r.id; renderAll(); };
                bodyEl.appendChild(b);
            });
        }
        panel.appendChild(bodyEl);
    }

    function emptyState(ic, title, sub, good) {
        return `<div class="slls-lv-empty ${good ? "good" : ""}">` +
            `<span class="slls-lv-ic">${ICON[ic] || ""}</span>` +
            `<h4>${esc(title)}</h4><p>${esc(sub)}</p></div>`;
    }

    function buildReportDetail(panel, r) {
        const hs = health(r);
        const brokenCount = (r.invalidObjects || []).length;
        const refMeta = `${r.objectCount} object reference${r.objectCount === 1 ? "" : "s"} \u00b7 ${brokenCount} broken`;
        const head = document.createElement("div");
        head.className = "slls-lv-panel-head";
        head.innerHTML =
            `<span class="slls-lv-ic">${ICON.report}</span>` +
            `<div class="slls-lv-pt"><div class="slls-lv-panel-title">${esc(r.name)}</div>` +
            `<div class="slls-lv-panel-sub">${ICON.workflow}<span>${esc(r.workspaceName)}</span></div>` +
            (hs === "broken"
                ? `<div class="slls-lv-panel-meta">${esc(refMeta)}</div>`
                : "") +
            `</div>` +
            `<button class="slls-lv-panel-close" title="Close">${ICON.close}</button>` +
            collapseBtn();
        head.querySelector(".slls-lv-panel-close").onclick = () => { selectedId = null; renderAll(); };
        head.querySelector('[data-act="collapse"]').onclick = () => {
            panelCollapsed = true; renderAll();
        };
        panel.appendChild(head);

        if (r.webUrl) {
            const a = document.createElement("a");
            a.className = "slls-lv-weblink";
            a.href = r.webUrl; a.target = "_blank"; a.rel = "noopener noreferrer";
            a.innerHTML = `${ICON.external}Open in Power BI`;
            panel.appendChild(a);
        }

        const bodyEl = document.createElement("div");
        bodyEl.className = "slls-lv-panel-body";
        if (hs === "error") {
            bodyEl.innerHTML = emptyState("alert", "Not analyzed",
                r.error || "This report could not be analyzed for broken elements.", false);
        } else if (hs === "clean") {
            bodyEl.innerHTML = emptyState("check", "No broken elements",
                "Every object this report references exists in the model.", true);
        } else {
            const secLabel = document.createElement("div");
            secLabel.className = "slls-lv-section-label";
            secLabel.textContent = "Broken elements";
            bodyEl.appendChild(secLabel);
            // invalidObjects are already grouped per model object (deduped in
            // Python), so each row is a single broken object with a fix picker.
            (r.invalidObjects || []).forEach((o) => {
                bodyEl.appendChild(buildBrokenRow(r, o));
            });
        }
        panel.appendChild(bodyEl);
    }

    function buildBrokenRow(r, o) {
        const d = document.createElement("div");
        d.className = "slls-lv-obj";
        const key = fixKey(r.id, o.objectType, o.table, o.name, o.hierarchy);
        const staged = stagedFixes.get(key);
        d.innerHTML =
            `<div class="slls-lv-obj-top">` +
            `<div class="slls-lv-obj-main">` +
            `<span class="slls-lv-obj-ic">${typeIcon(o.objectType)}</span>` +
            `<span class="slls-lv-obj-name">${esc(objLabel(o.objectType, o.table, o.name, o.hierarchy))}</span>` +
            `</div><span class="slls-lv-tag type">${esc(o.objectType)}</span></div>`;

        if (staged) {
            const fix = document.createElement("div");
            fix.className = "slls-lv-fix slls-lv-fix-staged";
            fix.innerHTML =
                `<span class="slls-lv-fix-ic">${ICON.wrench}</span>` +
                `<span class="slls-lv-staged">Point to ${esc(objLabel(o.objectType, staged.targetTable, staged.targetName, staged.targetHierarchy))}</span>` +
                `<button class="slls-lv-unstage" title="Undo fix">${ICON.undo}</button>`;
            fix.querySelector(".slls-lv-unstage").onclick = () => {
                stagedFixes.delete(key);
                renderAll();
            };
            d.appendChild(fix);
        } else {
            const cands = modelObjects()
                .filter((mo) => mo.type === o.objectType)
                .sort((a, b) => (o.objectType === "Measure"
                    ? a.name.toLowerCase().localeCompare(b.name.toLowerCase())
                    : (a.table + "\u0000" + (a.hierarchy || "") + "\u0000" + a.name).toLowerCase()
                        .localeCompare((b.table + "\u0000" + (b.hierarchy || "") + "\u0000" + b.name).toLowerCase())));
            const fix = document.createElement("div");
            fix.className = "slls-lv-fix";
            fix.appendChild(buildFixCombo(r, o, key, cands));
            d.appendChild(fix);
        }
        return d;
    }

    // Searchable combobox used to pick a replacement model object. A native
    // <select> cannot carry a table\u0000name value (the HTML parser strips NUL
    // from attribute values, which previously produced "[undefined]"), so we
    // reference the candidate objects directly from this closure instead.
    function buildFixCombo(r, o, key, cands) {
        const combo = document.createElement("div");
        combo.className = "slls-lv-combo";
        const input = document.createElement("input");
        input.type = "text";
        input.className = "slls-lv-combo-input";
        input.placeholder = "Apply fix\u2026";
        input.autocomplete = "off";
        input.spellcheck = false;
        const list = document.createElement("div");
        list.className = "slls-lv-combo-list";
        list.style.display = "none";

        function choose(mo) {
            stagedFixes.set(key, {
                reportId: r.id,
                reportName: r.name,
                reportWorkspace: r.workspaceName,
                objectType: o.objectType,
                brokenTable: o.table,
                brokenName: o.name,
                brokenHierarchy: o.hierarchy,
                targetTable: mo.table,
                targetName: mo.name,
                targetHierarchy: mo.hierarchy,
            });
            renderAll();
        }

        function renderList() {
            const q = input.value.trim().toLowerCase();
            const matches = cands.filter((mo) =>
                objLabel(mo.type, mo.table, mo.name, mo.hierarchy).toLowerCase().includes(q));
            list.innerHTML = "";
            if (matches.length === 0) {
                const em = document.createElement("div");
                em.className = "slls-lv-combo-empty";
                em.textContent = "No matches";
                list.appendChild(em);
                return;
            }
            matches.slice(0, 200).forEach((mo) => {
                const item = document.createElement("div");
                item.className = "slls-lv-combo-item";
                item.textContent = objLabel(mo.type, mo.table, mo.name, mo.hierarchy);
                // mousedown fires before the input blur, so the click registers.
                item.addEventListener("mousedown", (e) => { e.preventDefault(); choose(mo); });
                list.appendChild(item);
            });
        }

        input.addEventListener("focus", () => { renderList(); list.style.display = "block"; });
        input.addEventListener("input", () => { renderList(); list.style.display = "block"; });
        input.addEventListener("blur", () => { setTimeout(() => { list.style.display = "none"; }, 150); });
        input.addEventListener("keydown", (e) => {
            if (e.key === "Escape") { input.blur(); }
            else if (e.key === "Enter") {
                e.preventDefault();
                const first = list.querySelector(".slls-lv-combo-item");
                if (first) first.dispatchEvent(new MouseEvent("mousedown"));
            }
        });

        combo.appendChild(input);
        combo.appendChild(list);
        return combo;
    }

    function buildFooter() {
        const f = document.createElement("div");
        f.className = "slls-lv-footer";
        f.innerHTML = `Powered by <a href="https://github.com/microsoft/semantic-link-labs" ` +
            `target="_blank" rel="noopener noreferrer">Semantic Link Labs</a>`;
        return f;
    }

    // ---------- Model / workspace picker ("connect" screen) ----------
    function openPicker() {
        pickerReopen = true;
        pickWs = model.get("workspace_id") || "";
        pickDs = model.get("connected") ? "" : pickDs;
        ensureWorkspaces();
        ensureDatasets(pickWs);
        renderAll();
    }

    // Force a fresh fetch of the workspace list and the datasets for the
    // currently-selected workspace (used by the picker's Reload button).
    function reloadPickerLists() {
        workspacesRequested = false;
        ensureWorkspaces();
        if (pickWs) dispatch({ action: "list_datasets", workspace_id: pickWs });
    }

    function buildPickerScreen() {
        const wrap = document.createElement("div");
        wrap.className = "slls-lv-graphwrap slls-lv-picker-wrap";

        if (!pickWs) pickWs = model.get("workspace_id") || "";
        const workspaces = model.get("workspaces") || [];
        const ds = (model.get("datasets") || {})[pickWs] || null;

        const card = document.createElement("div");
        card.className = "slls-lv-picker";
        card.innerHTML =
            `<div class="slls-lv-picker-top">` +
                `<div class="slls-lv-picker-head">` +
                    `<div class="slls-lv-picker-title">Connect to a semantic model</div>` +
                    `<div class="slls-lv-picker-sub">Select a workspace and semantic model to begin.</div>` +
                `</div>` +
                `<button class="sl-reload-btn${working() ? " sl-spinning" : ""}" data-p="reload" type="button" ` +
                    `title="Reload workspaces and semantic models" aria-label="Reload workspaces and semantic models" ${working() ? "disabled" : ""}>${ICON.refresh}</button>` +
            `</div>` +
            `<div class="slls-lv-picker-grid">` +
                `<div class="slls-lv-field"><label>Workspace</label>` +
                    `<div data-p="ws"></div></div>` +
                `<div class="slls-lv-field"><label>Semantic model</label>` +
                    `<div data-p="ds"></div></div>` +
            `</div>` +
            `<div class="slls-lv-picker-actions">` +
                (connected()
                    ? `<button class="slls-lv-btn" data-p="cancel">Cancel</button>`
                    : "") +
                `<button class="slls-lv-btn slls-lv-btn-primary" data-p="connect" ${(!pickDs || working()) ? "disabled" : ""}>` +
                    `${working() ? spinner() : ""}Connect</button>` +
            `</div>`;

        const wsPicker = createSearchSelect({
            placeholder: "Select a workspace\u2026",
            searchPlaceholder: "Filter workspaces\u2026",
            ariaLabel: "Workspace",
            emptyLabel: working() ? "Loading workspaces\u2026" : "No workspaces",
            onChange: (option) => {
                pickWs = option.value;
                pickDs = "";
                ensureDatasets(pickWs);
                renderAll();
            },
        });
        wsPicker.setOptions(
            workspaces.map((w) => ({ value: w.id, label: w.name })), pickWs);
        wsPicker.setDisabled(working());
        card.querySelector('[data-p="ws"]').appendChild(wsPicker.el);

        const dsPicker = createSearchSelect({
            placeholder: "Select a semantic model\u2026",
            searchPlaceholder: "Filter semantic models\u2026",
            ariaLabel: "Semantic model",
            emptyLabel: !pickWs
                ? "Select a workspace first\u2026"
                : (ds === null ? "Loading semantic models\u2026" : "No semantic models"),
            onChange: (option) => { pickDs = option.value; renderAll(); },
        });
        dsPicker.setOptions(
            (ds || []).map((d) => ({ value: d.id, label: d.name })), pickDs);
        dsPicker.setDisabled(!pickWs || ds === null || working());
        card.querySelector('[data-p="ds"]').appendChild(dsPicker.el);

        card.querySelector('[data-p="reload"]').onclick = () => reloadPickerLists();
        const cancel = card.querySelector('[data-p="cancel"]');
        if (cancel) cancel.onclick = () => { pickerReopen = false; renderAll(); };
        card.querySelector('[data-p="connect"]').onclick = () => {
            if (!pickDs) return;
            const wsName = (workspaces.find((w) => w.id === pickWs) || {}).name || "";
            const dsName = ((ds || []).find((d) => d.id === pickDs) || {}).name || "";
            dispatch({
                action: "connect",
                workspace_id: pickWs,
                dataset_id: pickDs,
                workspace_name: wsName,
                dataset_name: dsName,
            });
        };

        wrap.appendChild(card);
        return wrap;
    }

    // ---------- Rebind modal ----------
    function openRebind() {
        rebindOpen = true;
        rebindWs = model.get("workspace_id") || "";
        rebindDs = "";
        ensureWorkspaces();
        ensureDatasets(rebindWs);
        renderAll();
    }

    function ensureWorkspaces() {
        // The full tenant workspace list is only needed for the rebind picker,
        // so it is fetched on demand (once) rather than at initial load.
        if (workspacesRequested) return;
        workspacesRequested = true;
        dispatch({ action: "list_workspaces" });
    }

    function ensureDatasets(wsId) {
        const ds = model.get("datasets") || {};
        if (wsId && !ds[wsId]) dispatch({ action: "list_datasets", workspace_id: wsId });
    }

    function buildRebindModal() {
        const overlay = document.createElement("div");
        overlay.className = "slls-lv-overlay";
        const workspaces = model.get("workspaces") || [];
        const ds = (model.get("datasets") || {})[rebindWs] || null;

        const modal = document.createElement("div");
        modal.className = "slls-lv-modal";
        modal.innerHTML =
            `<h3>Rebind ${picked.size} report${picked.size === 1 ? "" : "s"}</h3>` +
            `<p>Point the selected report${picked.size === 1 ? "" : "s"} at a different semantic model.</p>` +
            `<div class="slls-lv-field"><label>Target workspace</label>` +
            `<div data-r="ws"></div></div>` +
            `<div class="slls-lv-field"><label>Target semantic model</label>` +
            `<div data-r="ds"></div></div>` +
            `<div class="slls-lv-modal-actions">` +
            `<button class="slls-lv-btn" data-r="cancel">Cancel</button>` +
            `<button class="slls-lv-btn slls-lv-btn-primary" data-r="confirm" ${(!rebindDs || working()) ? "disabled" : ""}>` +
            `${ICON.link}Rebind${working() ? spinner() : ""}</button></div>`;

        const wsPicker = createSearchSelect({
            placeholder: "Select a workspace\u2026",
            searchPlaceholder: "Filter workspaces\u2026",
            ariaLabel: "Target workspace",
            emptyLabel: working() ? "Loading workspaces\u2026" : "No workspaces",
            onChange: (option) => {
                rebindWs = option.value;
                rebindDs = "";
                ensureDatasets(rebindWs);
                renderAll();
            },
        });
        wsPicker.setOptions(
            workspaces.map((w) => ({ value: w.id, label: w.name })), rebindWs);
        wsPicker.setDisabled(working());
        modal.querySelector('[data-r="ws"]').appendChild(wsPicker.el);

        const dsPicker = createSearchSelect({
            placeholder: "Select a semantic model\u2026",
            searchPlaceholder: "Filter semantic models\u2026",
            ariaLabel: "Target semantic model",
            emptyLabel: ds === null ? "Loading semantic models\u2026" : "No semantic models",
            onChange: (option) => { rebindDs = option.value; renderAll(); },
        });
        dsPicker.setOptions(
            (ds || []).map((d) => ({ value: d.id, label: d.name })), rebindDs);
        dsPicker.setDisabled(ds === null || working());
        modal.querySelector('[data-r="ds"]').appendChild(dsPicker.el);

        modal.querySelector('[data-r="cancel"]').onclick = () => { rebindOpen = false; renderAll(); };
        modal.querySelector('[data-r="confirm"]').onclick = () => {
            if (!rebindDs) return;
            dispatch({
                action: "rebind",
                report_ids: [...picked],
                dataset_id: rebindDs,
                dataset_workspace_id: rebindWs,
            });
        };
        overlay.appendChild(modal);
        overlay.addEventListener("pointerdown", (e) => {
            if (e.target === overlay) { rebindOpen = false; renderAll(); }
        });
        return overlay;
    }

    // ---------- Node width resize ----------
    // A thin grip on each node's right edge lets the user widen / narrow the
    // nodes. Report nodes share one width and the model (center) node has its
    // own, so a single grip resizes every node of that type in lockstep.
    function makeResizeGrip(isModel) {
        const grip = document.createElement("div");
        grip.className = "slls-lv-node-resize";
        grip.title = "Drag to resize width (double-click to auto-fit)";
        grip.addEventListener("pointerdown", (e) => startNodeResize(e, isModel));
        grip.addEventListener("click", (e) => e.stopPropagation());
        grip.addEventListener("dblclick", (e) => {
            e.stopPropagation();
            if (isModel) centerWOverride = null; else nodeWOverride = null;
            computeNodeWidths();
            applyNodeSizes();
        });
        return grip;
    }

    // Push the current node widths onto the existing DOM in place. Node centres
    // (positions) are left untouched so resizing never moves a node or shifts
    // the viewport — the node simply grows / shrinks about its own centre.
    function applyNodeSizes() {
        const mp = positions[MODEL_KEY];
        const mEl = document.getElementById("slls-lv-node-" + MODEL_KEY);
        if (mEl && mp) {
            mEl.style.width = CENTER_W + "px";
            mEl.style.left = (mp.x - CENTER_W / 2) + "px";
        }
        reports().forEach((r) => {
            const el = document.getElementById("slls-lv-node-" + r.id);
            const p = positions[r.id];
            if (el && p) {
                el.style.width = NODE_W + "px";
                el.style.left = (p.x - NODE_W / 2) + "px";
            }
        });
        updateEdges(MODEL_KEY);
    }

    function startNodeResize(e, isModel) {
        if (e.button != null && e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        const startX = e.clientX;
        const startW = isModel ? CENTER_W : NODE_W;
        const MINW = 140, MAXW = 720;
        const move = (ev) => {
            // Nodes are positioned by their centre, so grow symmetrically and
            // double the delta so the right edge tracks the pointer. Widths are
            // applied in place (no re-render) so the node stays put.
            const w = Math.round(Math.min(MAXW, Math.max(MINW,
                startW + 2 * (ev.clientX - startX) / zoom)));
            if (isModel) { CENTER_W = w; centerWOverride = w; }
            else { NODE_W = w; nodeWOverride = w; }
            applyNodeSizes();
        };
        const up = () => {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
            document.body.style.userSelect = "";
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
        document.body.style.userSelect = "none";
    }

    // ---------- Dragging (nodes) ----------
    let dragMoved = false;
    function startDrag(e, key) {
        if (e.button != null && e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        dragMoved = false;
        const start = positions[key] || { x: 0, y: 0 };
        const ox = e.clientX, oy = e.clientY;
        const node = document.getElementById("slls-lv-node-" + key);
        const half = key === MODEL_KEY ? { w: CENTER_W / 2, h: CENTER_H / 2 } : { w: NODE_W / 2, h: NODE_H / 2 };

        function move(ev) {
            const dx = (ev.clientX - ox) / zoom;
            const dy = (ev.clientY - oy) / zoom;
            if (Math.abs(ev.clientX - ox) + Math.abs(ev.clientY - oy) > 4) dragMoved = true;
            const nx = Math.max(half.w, start.x + dx);
            const ny = Math.max(half.h, start.y + dy);
            positions[key] = { x: nx, y: ny };
            if (node) {
                node.style.left = (nx - half.w) + "px";
                node.style.top = (ny - half.h) + "px";
            }
            updateEdges(key);
        }
        function up() {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
            document.body.style.userSelect = "";
        }
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
        document.body.style.userSelect = "none";
    }

    function updateEdges(key) {
        const m = positions[MODEL_KEY];
        const rs = key === MODEL_KEY ? reports() : reports().filter((r) => r.id === key);
        rs.forEach((r) => {
            const p = positions[r.id];
            const line = document.getElementById("slls-lv-edge-" + r.id);
            if (!p || !line) return;
            const a = edgePoint(m.x, m.y, p.x, p.y, CENTER_W / 2, CENTER_H / 2);
            const b = edgePoint(p.x, p.y, m.x, m.y, NODE_W / 2, NODE_H / 2);
            line.setAttribute("x1", a.x); line.setAttribute("y1", a.y);
            line.setAttribute("x2", b.x); line.setAttribute("y2", b.y);
        });
    }

    function attachGraphInteractions() { /* listeners attached during build */ }

    // ---------- Model change wiring ----------
    // Any result arriving from the back-end also clears the local working flag.
    function settle() { busyLocal = false; renderAll(); }
    model.on("change:reports", settle);
    model.on("change:analyzed", settle);
    model.on("change:busy", settle);
    model.on("change:status", settle);
    // A successful connect flips "connected"; drop the picker and reset any
    // stale per-model selections so the fresh model's graph is shown.
    model.on("change:connected", () => {
        busyLocal = false;
        if (model.get("connected")) {
            pickerReopen = false;
            selectedId = null;
            picked = new Set();
            stagedFixes = new Map();
        }
        renderAll();
    });
    // connect_done fires on every successful connect (including switching to a
    // new model while already connected, where "connected" stays true and the
    // observer above would not fire) so the picker always closes.
    model.on("change:connect_done", () => {
        busyLocal = false;
        pickerReopen = false;
        selectedId = null;
        picked = new Set();
        stagedFixes = new Map();
        renderAll();
    });
    model.on("change:workspaces", () => { if (rebindOpen || showPicker()) renderAll(); });
    model.on("change:datasets", () => { busyLocal = false; if (rebindOpen || showPicker()) renderAll(); });
    model.on("change:model_objects", () => { if (selectedId) renderAll(); });
    model.on("change:rebind_done", () => {
        busyLocal = false; rebindOpen = false; picked = new Set(); selectedId = null; renderAll();
    });
    model.on("change:fixes_saved", () => {
        busyLocal = false; stagedFixes = new Map(); renderAll();
    });

    renderAll();
}
export default { render };
"""

from sempy_labs._ui_components import (  # noqa: E402
    ICONS as _UI_ICONS,
    SEARCH_SELECT_CSS as _UI_SEARCH_SELECT_CSS,
    SEARCH_SELECT_JS as _UI_SEARCH_SELECT_JS,
    scoped_button_press_css as _ui_scoped_button_press_css,
    scoped_header_css as _ui_scoped_header_css,
)

_WIDGET_CSS += "\n" + _UI_SEARCH_SELECT_CSS
_WIDGET_CSS += _ui_scoped_header_css(".slls-lv")
_WIDGET_CSS += _ui_scoped_button_press_css(".slls-lv")

_WIDGET_JS = _UI_SEARCH_SELECT_JS + "\n" + _WIDGET_JS

_WIDGET_JS = (
    _WIDGET_JS.replace("__ICON_DATABASE__", _UI_ICONS["database"])
    .replace("__ICON_REPORT__", _UI_ICONS["report"])
    .replace("__ICON_REFRESH__", _UI_ICONS["refresh"])
    .replace("__ICON_SCAN__", _UI_ICONS["scan"])
    .replace("__ICON_LINK__", _UI_ICONS["link"])
    .replace("__ICON_CHECK__", _UI_ICONS["check_circle"])
    .replace("__ICON_ALERT__", _UI_ICONS["alert"])
    .replace("__ICON_EXTERNAL__", _UI_ICONS["external_link"])
    .replace("__ICON_ZOOMIN__", _UI_ICONS["zoom_in"])
    .replace("__ICON_ZOOMOUT__", _UI_ICONS["zoom_out"])
    .replace("__ICON_CLOSE__", _UI_ICONS["close"])
    .replace("__ICON_WORKFLOW__", _UI_ICONS["workflow"])
    .replace("__ICON_SUN__", _UI_ICONS["sun"])
    .replace("__ICON_MOON__", _UI_ICONS["moon"])
    .replace("__ICON_FULLSCREEN__", _UI_ICONS["fullscreen"])
    .replace("__ICON_FULLSCREEN_EXIT__", _UI_ICONS["fullscreen_exit"])
    .replace("__ICON_MEASURE__", _UI_ICONS["measure"])
    .replace("__ICON_COLUMN__", _UI_ICONS["column"])
    .replace("__ICON_HIERARCHY__", _UI_ICONS["hierarchy"])
    .replace("__ICON_SAVE__", _UI_ICONS["save"])
    .replace("__ICON_WRENCH__", _UI_ICONS["wrench"])
    .replace("__ICON_UNDO__", _UI_ICONS["undo"])
    .replace("__ICON_CHEVRON_LEFT__", _UI_ICONS["chevron_left"])
    .replace("__ICON_CHEVRON_RIGHT__", _UI_ICONS["chevron_right"])
    .replace("__ICON_SWAP__", _UI_ICONS["swap"])
)


@log
def lineage_view(
    dataset: Optional[str | UUID] = None,
    workspace: Optional[str | UUID] = None,
    dark_mode: bool = False,
):
    """
    Displays an interactive lineage view for a semantic model.

    Shows a node graph placing the semantic model at the center with each downstream report
    (i.e. the reports in the model's workspace that consume it) arranged around
    it. Each report can be analyzed for broken elements — references to columns,
    measures or hierarchies that no longer exist in the semantic model — with a
    side panel summarizing the results per report. Selecting a broken report
    lists its broken objects (grouped by object); a valid replacement object can
    be chosen from the model to stage a fix, and the staged fixes are written
    back to the report(s) with the Save button. Reports can also be selected and
    rebound to a different semantic model.


    Both the 'PBIR' and 'PBIRLegacy' report formats are supported for
    broken-element analysis and fixes.

    Parameters
    ----------
    dataset : str | uuid.UUID, default=None
        Name or ID of the semantic model.
        Defaults to None which opens the view on a workspace / semantic model
        picker so the model to evaluate can be chosen interactively.
    workspace : str | uuid.UUID, default=None
        The Fabric workspace name or ID.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    dark_mode : bool, default=False
        If True, renders the view with a dark color theme. If False, renders with
        a light color theme.
    """

    try:
        import anywidget
        import traitlets
    except ImportError as e:
        raise ImportError(
            "The 'lineage_view' function requires the 'anywidget' package. "
            "Install it with: pip install anywidget"
        ) from e

    import sempy.fabric as fabric
    from IPython.display import display
    from sempy_labs._helper_functions import (
        resolve_workspace_name_and_id,
        resolve_dataset_name_and_id,
        format_dax_object_name,
        _base_api,
    )
    from sempy_labs._list_functions import list_reports_using_semantic_model
    from sempy_labs.report._report_rebind import report_rebind

    ws_name, ws_id = resolve_workspace_name_and_id(workspace)
    ws_id = str(ws_id)
    # When no dataset is supplied the view opens on the model/workspace picker
    # and stays disconnected until the user chooses a model to evaluate.
    connected = dataset is not None
    if connected:
        ds_name, ds_id = resolve_dataset_name_and_id(dataset, ws_id)
        ds_id = str(ds_id)
    else:
        ds_name, ds_id = "", ""

    def _web_url_map():
        """Report Id -> Web Url, best effort."""
        try:
            dfAll = fabric.list_reports(workspace=ws_id)
        except Exception:
            return {}
        cols = list(dfAll.columns)
        id_col = "Id" if "Id" in cols else (cols[0] if cols else None)
        url_col = next((c for c in cols if "url" in c.lower()), None)
        if id_col is None or url_col is None:
            return {}
        return {
            str(r[id_col]): (str(r[url_col]) if r[url_col] else None)
            for _, r in dfAll.iterrows()
        }

    def _model_objects_full():
        """Valid model objects.

        Returns the sets of valid measure names, fully-qualified column names,
        fully-qualified hierarchy names and fully-qualified hierarchy-level
        names (used to detect broken references), plus an ordered list of
        ``{table, name, type}`` objects offered as fix targets. Hierarchy-level
        objects additionally carry a ``hierarchy`` key.
        """
        from sempy_labs.tom import connect_semantic_model

        measures = set()
        columns = set()
        hierarchies = set()
        hierarchy_levels = set()
        objects = []
        with connect_semantic_model(
            dataset=ds_id, readonly=True, workspace=ws_id
        ) as tom:
            for m in tom.all_measures():
                measures.add(m.Name)
                objects.append(
                    {"table": m.Parent.Name, "name": m.Name, "type": "Measure"}
                )
            for c in tom.all_columns():
                columns.add(format_dax_object_name(c.Parent.Name, c.Name))
                objects.append(
                    {"table": c.Parent.Name, "name": c.Name, "type": "Column"}
                )
            for h in tom.all_hierarchies():
                hqual = format_dax_object_name(h.Parent.Name, h.Name)
                hierarchies.add(hqual)
                objects.append(
                    {"table": h.Parent.Name, "name": h.Name, "type": "Hierarchy"}
                )
                for lvl in h.Levels:
                    hierarchy_levels.add(f"{hqual}.{lvl.Name}")
                    objects.append(
                        {
                            "table": h.Parent.Name,
                            "hierarchy": h.Name,
                            "name": lvl.Name,
                            "type": "Hierarchy Level",
                        }
                    )
        return measures, columns, hierarchies, hierarchy_levels, objects

    # ------------------------------------------------------------------
    # Report definition extractor / mutator.
    #
    # Works for both the 'PBIR' (multiple JSON parts) and 'PBIRLegacy' (single
    # report.json with stringified config/query blobs) formats by walking every
    # part's JSON and descending into any stringified JSON blobs. Ports the
    # 'Tools' app's ReportObjectExtractor so this tool does not depend on the
    # PBIR-only ReportWrapper. Resolves both direct SourceRef.Entity references
    # and aliased SourceRef.Source references via each query's From clause.
    # ------------------------------------------------------------------
    def _get_report_definition(report_id):
        result = _base_api(
            request=(f"/v1/workspaces/{ws_id}/items/{report_id}/getDefinition"),
            method="post",
            status_codes=None,
            lro_return_json=True,
            client="fabric_sp",
        )
        return result.get("definition", {}).get("parts", [])

    def _looks_like_json(s):
        t = s.lstrip()
        return t.startswith("{") or t.startswith("[")

    def _walk_refs(node, parent_key, aliases, refs, report_measures):
        if isinstance(node, dict):
            # A 'From' clause maps query aliases (Source) to entities (tables).
            local_aliases = aliases
            frm = node.get("From")
            if isinstance(frm, list):
                local_aliases = dict(aliases)
                for f in frm:
                    if isinstance(f, dict):
                        alias = f.get("Name")
                        ent = f.get("Entity")
                        if isinstance(alias, str) and alias and isinstance(ent, str):
                            local_aliases[alias] = ent

            # Report-level measures live in entities[].measures[].name; they are
            # defined in the report (not the model) so must not be flagged broken.
            entities = node.get("entities")
            if isinstance(entities, list):
                for ent in entities:
                    if isinstance(ent, dict) and isinstance(ent.get("measures"), list):
                        for m in ent["measures"]:
                            if isinstance(m, dict) and isinstance(m.get("name"), str):
                                if m["name"]:
                                    report_measures.add(m["name"])

            # Hierarchy level: a HierarchyLevel node nests the hierarchy (with
            # its own SourceRef) and carries the level name. Record the (table,
            # hierarchy, level) triple and stop descending so the nested
            # hierarchy is not also counted as a standalone Hierarchy reference.
            hl_level = node.get("Level")
            hl_expr = node.get("Expression")
            if (
                isinstance(hl_level, str)
                and hl_level
                and isinstance(hl_expr, dict)
                and isinstance(hl_expr.get("Hierarchy"), dict)
            ):
                h_node = hl_expr["Hierarchy"]
                h_name = h_node.get("Hierarchy")
                h_inner = h_node.get("Expression")
                h_entity = None
                if isinstance(h_inner, dict) and isinstance(
                    h_inner.get("SourceRef"), dict
                ):
                    h_src = h_inner["SourceRef"]
                    if isinstance(h_src.get("Entity"), str) and h_src["Entity"]:
                        h_entity = h_src["Entity"]
                    else:
                        h_alias = h_src.get("Source")
                        if isinstance(h_alias, str) and h_alias in local_aliases:
                            h_entity = local_aliases[h_alias]
                if h_entity and isinstance(h_name, str) and h_name:
                    refs[("Hierarchy Level", h_entity, h_name, hl_level)] = {
                        "table": h_entity,
                        "hierarchy": h_name,
                        "name": hl_level,
                        "objectType": "Hierarchy Level",
                    }
                    return

            expr = node.get("Expression")
            if isinstance(expr, dict) and isinstance(expr.get("SourceRef"), dict):
                src = expr["SourceRef"]
                entity = None
                if isinstance(src.get("Entity"), str) and src["Entity"]:
                    entity = src["Entity"]
                else:
                    alias = src.get("Source")
                    if isinstance(alias, str) and alias in local_aliases:
                        entity = local_aliases[alias]
                if entity:
                    prop = node.get("Property")
                    hier = node.get("Hierarchy")
                    if isinstance(prop, str) and prop:
                        otype = "Measure" if parent_key == "Measure" else "Column"
                        refs[(otype, entity, prop)] = {
                            "table": entity,
                            "name": prop,
                            "objectType": otype,
                        }
                    elif isinstance(hier, str) and hier:
                        refs[("Hierarchy", entity, hier)] = {
                            "table": entity,
                            "name": hier,
                            "objectType": "Hierarchy",
                        }

            for k, v in node.items():
                if isinstance(v, str) and _looks_like_json(v):
                    # PBIRLegacy stores visual config / query as stringified JSON.
                    try:
                        inner = json.loads(v)
                    except Exception:
                        inner = None
                    if inner is not None:
                        _walk_refs(inner, k, local_aliases, refs, report_measures)
                else:
                    _walk_refs(v, k, local_aliases, refs, report_measures)
        elif isinstance(node, list):
            for item in node:
                _walk_refs(item, parent_key, aliases, refs, report_measures)

    def _extract_report_objects(parts):
        refs = {}
        report_measures = set()
        for part in parts:
            payload = part.get("payload")
            if not payload:
                continue
            try:
                node = json.loads(base64.b64decode(payload).decode("utf-8"))
            except Exception:
                continue
            _walk_refs(node, None, {}, refs, report_measures)
        return list(refs.values()), report_measures

    def _rewrite_ref_string(s, fixes, native=False):
        """Rewrite a query-alias string in place.

        Handles the qualified alias strings (``queryRef``, ``Name``,
        ``metadata``) and, when ``native`` is True, the bare display strings
        (``nativeQueryRef``, ``NativeReferenceName``).

        Matching is anchored to the whole token so renaming an object never
        corrupts a longer friendly name (e.g. renaming ``Table.Fiscal`` must not
        touch ``Table.Fiscal Year``). Both the plain ``Table.Column`` form and
        the aggregation / bracket wrapped forms (``Sum(Table.Column)``,
        ``[Table.Column]``) are supported.
        """
        result = s
        for fx in fixes:
            if str(fx.get("objectType", "")).lower() == "hierarchy level":
                # queryRef: 'Table.Hierarchy.Level'; nativeQueryRef: 'Hierarchy Level'.
                old_h = fx.get("oldHierarchy") or ""
                new_h = fx.get("newHierarchy") or ""
                if native:
                    old_disp = f"{old_h} {fx['oldName']}"
                    new_disp = f"{new_h} {fx['newName']}"
                    if result.lower() == old_disp.lower():
                        result = new_disp
                else:
                    old_q = f"{fx['oldTable']}.{old_h}.{fx['oldName']}"
                    new_q = f"{fx['newTable']}.{new_h}.{fx['newName']}"
                    if result.lower() == old_q.lower():
                        result = new_q
                continue
            old_qual = f"{fx['oldTable']}.{fx['oldName']}"
            new_qual = f"{fx['newTable']}.{fx['newName']}"
            if native:
                # Display names carry only the bare object name.
                if result.lower() == str(fx["oldName"]).lower():
                    result = fx["newName"]
                continue
            low = result.lower()
            if low == old_qual.lower():
                result = new_qual
            elif low == f"[{old_qual}]".lower():
                result = f"[{new_qual}]"
            else:
                # Aggregation wrapper, e.g. "Sum(Table.Column)".
                m = re.match(r"^([A-Za-z]\w*)\((.+)\)$", result)
                if m and m.group(2).lower() == old_qual.lower():
                    result = f"{m.group(1)}({new_qual})"
        return result

    def _new_from_alias(from_list, table):
        """Return an unused query alias for ``table`` within ``from_list``."""
        base = "".join(ch for ch in table.lower() if ch.isalnum()) or "t"
        used = {str(f.get("Name", "")) for f in from_list if isinstance(f, dict)}
        if base not in used:
            return base
        i = 1
        while f"{base}{i}" in used:
            i += 1
        return f"{base}{i}"

    def _repoint_source_ref(src, entity_based, from_list, new_table):
        """Point a ``SourceRef`` at ``new_table`` for a cross-table fix.

        Direct references update ``Entity`` in place. Aliased references reuse an
        existing ``From`` alias for the target table (or append a new one) so
        that sibling references to the original table are left untouched.
        """
        if entity_based:
            src["Entity"] = new_table
            return
        if not isinstance(from_list, list):
            return
        existing = next(
            (
                f.get("Name")
                for f in from_list
                if isinstance(f, dict)
                and str(f.get("Entity", "")).lower() == new_table.lower()
            ),
            None,
        )
        if existing:
            src["Source"] = existing
        else:
            alias = _new_from_alias(from_list, new_table)
            from_list.append({"Name": alias, "Entity": new_table, "Type": 0})
            src["Source"] = alias

    def _mutate_reference(obj, parent_key, aliases, from_list, fixes):
        expr = obj.get("Expression")
        if not isinstance(expr, dict) or not isinstance(expr.get("SourceRef"), dict):
            return
        src = expr["SourceRef"]
        entity_based = False
        entity = None
        if isinstance(src.get("Entity"), str) and src["Entity"]:
            entity = src["Entity"]
            entity_based = True
        else:
            alias = src.get("Source")
            if isinstance(alias, str) and alias in aliases:
                entity = aliases[alias]
        if not entity:
            return
        prop = obj.get("Property")
        hier = obj.get("Hierarchy")
        if isinstance(prop, str) and prop:
            ref_type = "Measure" if parent_key == "Measure" else "Column"
            for fx in fixes:
                if (
                    fx["objectType"].lower() == ref_type.lower()
                    and entity.lower() == fx["oldTable"].lower()
                    and prop.lower() == fx["oldName"].lower()
                ):
                    obj["Property"] = fx["newName"]
                    if fx["newTable"].lower() != fx["oldTable"].lower():
                        _repoint_source_ref(
                            src, entity_based, from_list, fx["newTable"]
                        )
                    break
        elif isinstance(hier, str) and hier:
            for fx in fixes:
                if (
                    fx["objectType"].lower() == "hierarchy"
                    and entity.lower() == fx["oldTable"].lower()
                    and hier.lower() == fx["oldName"].lower()
                ):
                    obj["Hierarchy"] = fx["newName"]
                    if fx["newTable"].lower() != fx["oldTable"].lower():
                        _repoint_source_ref(
                            src, entity_based, from_list, fx["newTable"]
                        )
                    break

    def _mutate_hierarchy_level(obj, aliases, from_list, fixes):
        """Repoint a HierarchyLevel node for a staged hierarchy-level fix.

        A HierarchyLevel node nests the hierarchy (with its own SourceRef) and
        carries the ``Level`` name, so the table, hierarchy and level are all
        updated together to match the chosen replacement.
        """
        level = obj.get("Level")
        expr = obj.get("Expression")
        if not (isinstance(level, str) and level and isinstance(expr, dict)):
            return
        h_node = expr.get("Hierarchy")
        if not isinstance(h_node, dict):
            return
        h_name = h_node.get("Hierarchy")
        h_inner = h_node.get("Expression")
        if not (
            isinstance(h_name, str)
            and h_name
            and isinstance(h_inner, dict)
            and isinstance(h_inner.get("SourceRef"), dict)
        ):
            return
        src = h_inner["SourceRef"]
        entity_based = False
        entity = None
        if isinstance(src.get("Entity"), str) and src["Entity"]:
            entity = src["Entity"]
            entity_based = True
        else:
            alias = src.get("Source")
            if isinstance(alias, str) and alias in aliases:
                entity = aliases[alias]
        if not entity:
            return
        for fx in fixes:
            if (
                str(fx.get("objectType", "")).lower() == "hierarchy level"
                and entity.lower() == fx["oldTable"].lower()
                and h_name.lower() == str(fx.get("oldHierarchy") or "").lower()
                and level.lower() == fx["oldName"].lower()
            ):
                obj["Level"] = fx["newName"]
                h_node["Hierarchy"] = fx.get("newHierarchy") or h_name
                if fx["newTable"].lower() != fx["oldTable"].lower():
                    _repoint_source_ref(src, entity_based, from_list, fx["newTable"])
                break

    def _mutate_walk(node, parent_key, aliases, from_list, fixes):
        if isinstance(node, dict):
            local_aliases = aliases
            local_from = from_list
            frm = node.get("From")
            if isinstance(frm, list):
                local_aliases = dict(aliases)
                local_from = frm
                for f in frm:
                    if isinstance(f, dict):
                        alias = f.get("Name")
                        ent = f.get("Entity")
                        if isinstance(alias, str) and alias and isinstance(ent, str):
                            local_aliases[alias] = ent
            _mutate_reference(node, parent_key, local_aliases, local_from, fixes)
            _mutate_hierarchy_level(node, local_aliases, local_from, fixes)
            for k in list(node.keys()):
                v = node[k]
                if isinstance(v, str):
                    # Rewrite query aliases so they stay in sync with the
                    # structured reference mutated above. These are checked
                    # before the stringified-JSON branch because a bracketed
                    # alias such as "[Table.Column]" also starts with "[".
                    if k in ("queryRef", "metadata", "Name"):
                        node[k] = _rewrite_ref_string(v, fixes)
                    elif k in ("nativeQueryRef", "NativeReferenceName"):
                        node[k] = _rewrite_ref_string(v, fixes, native=True)
                    elif _looks_like_json(v):
                        try:
                            inner = json.loads(v)
                        except Exception:
                            inner = None
                        if inner is not None:
                            _mutate_walk(inner, k, local_aliases, local_from, fixes)
                            node[k] = json.dumps(inner)
                else:
                    _mutate_walk(v, k, local_aliases, local_from, fixes)
        elif isinstance(node, list):
            for item in node:
                _mutate_walk(item, parent_key, aliases, from_list, fixes)

    def _apply_report_fixes(report_id, fixes):
        parts = _get_report_definition(report_id)
        out_parts = []
        for part in parts:
            path = part.get("path", "")
            payload = part.get("payload")
            out_payload = payload or ""
            if payload:
                try:
                    node = json.loads(base64.b64decode(payload).decode("utf-8"))
                except Exception:
                    node = None
                if node is not None:
                    _mutate_walk(node, None, {}, None, fixes)
                    out_payload = base64.b64encode(
                        json.dumps(node).encode("utf-8")
                    ).decode("utf-8")
            out_parts.append(
                {"path": path, "payload": out_payload, "payloadType": "InlineBase64"}
            )
        _base_api(
            request=(f"/v1/workspaces/{ws_id}/reports/{report_id}/updateDefinition"),
            method="post",
            payload={"definition": {"parts": out_parts}},
            status_codes=None,
            lro_return_status_code=True,
            client="fabric_sp",
        )

    def _build_reports(analyze):
        """Return the list of downstream-report payload dicts."""
        dfR = list_reports_using_semantic_model(dataset=ds_id, workspace=ws_id)
        url_map = _web_url_map()
        reports = []
        for _, r in dfR.iterrows():
            reports.append(
                {
                    "id": str(r["Report Id"]),
                    "name": str(r["Report Name"]),
                    "workspaceName": str(r["Report Workspace Name"]),
                    "webUrl": url_map.get(str(r["Report Id"])),
                    "objectCount": 0,
                    "invalidCount": 0,
                    "analyzed": False,
                    "error": None,
                    "invalidObjects": [],
                }
            )

        if not analyze or not reports:
            return reports

        # Re-capture the model metadata on every analysis (including
        # Re-analyze) so the valid fix targets and broken-element checks
        # reflect any changes to the model since the view was opened.
        measures, columns, hierarchies, hierarchy_levels, objects = (
            _model_objects_full()
        )
        widget.model_objects = objects

        for rep in reports:
            try:
                parts = _get_report_definition(rep["id"])
                references, report_measures = _extract_report_objects(parts)
                invalid = []
                for ref in references:
                    otype = ref["objectType"]
                    tname = ref["table"]
                    oname = ref["name"]
                    if otype == "Measure":
                        valid = oname in measures or oname in report_measures
                    elif otype == "Column":
                        valid = format_dax_object_name(tname, oname) in columns
                    elif otype == "Hierarchy":
                        valid = format_dax_object_name(tname, oname) in hierarchies
                    elif otype == "Hierarchy Level":
                        hkey = (
                            format_dax_object_name(tname, ref.get("hierarchy"))
                            + f".{oname}"
                        )
                        valid = hkey in hierarchy_levels
                    else:
                        valid = True
                    if not valid:
                        invalid.append(
                            {
                                "table": tname,
                                "name": oname,
                                "objectType": otype,
                                "hierarchy": ref.get("hierarchy"),
                            }
                        )
                rep["objectCount"] = len(references)
                rep["invalidCount"] = len(invalid)
                rep["invalidObjects"] = invalid
                rep["analyzed"] = True
            except Exception as e:
                rep["analyzed"] = False
                rep["error"] = str(e)

        return reports

    def _list_workspaces_payload():
        try:
            dfW = fabric.list_workspaces()
        except Exception:
            return [{"id": ws_id, "name": str(ws_name or "")}]
        cols = list(dfW.columns)
        id_col = "Id" if "Id" in cols else cols[0]
        name_col = "Name" if "Name" in cols else cols[-1]
        out = [
            {"id": str(r[id_col]), "name": str(r[name_col])} for _, r in dfW.iterrows()
        ]
        return sorted(out, key=lambda x: x["name"].lower())

    def _list_datasets_payload(target_ws_id):
        try:
            dfD = fabric.list_datasets(workspace=target_ws_id)
        except Exception:
            return []
        cols = list(dfD.columns)
        id_col = next(
            (c for c in ["Dataset Id", "Dataset ID", "Id"] if c in cols),
            cols[0] if cols else None,
        )
        name_col = next(
            (c for c in ["Dataset Name", "Name"] if c in cols),
            cols[-1] if cols else None,
        )
        if id_col is None or name_col is None:
            return []
        out = [
            {"id": str(r[id_col]), "name": str(r[name_col])} for _, r in dfD.iterrows()
        ]
        return sorted(out, key=lambda x: x["name"].lower())

    # Initial load (downstream reports only, no analysis). When no model is
    # connected yet the graph is not built; the picker is shown instead.
    if connected:
        try:
            initial_reports = _build_reports(analyze=False)
            initial_status = {}
        except Exception as e:
            initial_reports = []
            initial_status = {"message": f"Error loading lineage: {e}", "kind": "error"}
    else:
        initial_reports = []
        initial_status = {}

    # When starting on the picker, prefetch the full tenant workspace list and
    # the current workspace's semantic models so the dropdowns populate at once.
    if connected:
        initial_workspaces = [{"id": ws_id, "name": ws_name or ""}]
        initial_datasets = {}
    else:
        initial_workspaces = _list_workspaces_payload()
        initial_datasets = {ws_id: _list_datasets_payload(ws_id)}

    # Valid model objects (fix targets) require a TOM connection to the model,
    # so they are loaded lazily on the first analysis rather than at load time.
    # Fixes can only be staged after analysing, and _build_reports(analyze=True)
    # repopulates model_objects, so nothing is lost by deferring this.
    initial_model_objects = []

    class LineageViewWidget(anywidget.AnyWidget):
        _esm = _WIDGET_JS
        _css = _WIDGET_CSS

        dataset_name = traitlets.Unicode("").tag(sync=True)
        workspace_name = traitlets.Unicode("").tag(sync=True)
        workspace_id = traitlets.Unicode("").tag(sync=True)
        connected = traitlets.Bool(False).tag(sync=True)
        reports = traitlets.List().tag(sync=True)
        analyzed = traitlets.Bool(False).tag(sync=True)
        model_objects = traitlets.List().tag(sync=True)
        workspaces = traitlets.List().tag(sync=True)
        datasets = traitlets.Dict().tag(sync=True)
        status = traitlets.Dict().tag(sync=True)
        pending_action = traitlets.Dict().tag(sync=True)
        run = traitlets.Int(0).tag(sync=True)
        rebind_done = traitlets.Int(0).tag(sync=True)
        fixes_saved = traitlets.Int(0).tag(sync=True)
        connect_done = traitlets.Int(0).tag(sync=True)
        busy = traitlets.Bool(False).tag(sync=True)
        dark_mode = traitlets.Bool(False).tag(sync=True)

    widget = LineageViewWidget(
        dataset_name=ds_name,
        workspace_name=ws_name or "",
        workspace_id=ws_id,
        connected=connected,
        reports=initial_reports,
        analyzed=False,
        model_objects=initial_model_objects,
        # Seed with the current workspace for an immediate default; the full
        # tenant workspace list is fetched lazily when the rebind modal opens.
        workspaces=initial_workspaces,
        datasets=initial_datasets,
        status=initial_status,
        pending_action={},
        run=0,
        rebind_done=0,
        fixes_saved=0,
        connect_done=0,
        busy=False,
        dark_mode=bool(dark_mode),
    )

    def _on_run(_change):
        nonlocal ws_id, ds_id, ws_name, ds_name
        data = dict(widget.pending_action or {})
        action = data.get("action")
        if not action:
            return
        widget.busy = True
        try:
            if action == "analyze":
                widget.reports = _build_reports(analyze=True)
                widget.analyzed = True
                widget.status = {}

            elif action == "refresh":
                keep = widget.analyzed
                widget.reports = _build_reports(analyze=keep)
                widget.status = {"message": "Lineage refreshed.", "kind": "success"}

            elif action == "list_datasets":
                target_ws = data.get("workspace_id")
                if target_ws:
                    new_map = dict(widget.datasets)
                    new_map[str(target_ws)] = _list_datasets_payload(target_ws)
                    widget.datasets = new_map

            elif action == "list_workspaces":
                widget.workspaces = _list_workspaces_payload()

            elif action == "connect":
                target_ws = data.get("workspace_id")
                target_ds = data.get("dataset_id")
                if not target_ws or not target_ds:
                    widget.status = {
                        "message": "Select a workspace and semantic model.",
                        "kind": "error",
                    }
                    return
                # Repoint the closure-captured identifiers so every helper
                # (report loader, TOM connection, fix writer, ...) targets the
                # newly chosen model / workspace.
                ws_id = str(target_ws)
                ds_id = str(target_ds)
                ws_name = data.get("workspace_name") or ws_name
                ds_name = data.get("dataset_name") or ds_name
                widget.dataset_name = ds_name
                widget.workspace_name = ws_name
                widget.workspace_id = ws_id
                widget.model_objects = []
                widget.analyzed = False
                widget.reports = _build_reports(analyze=False)
                widget.connected = True
                widget.connect_done = widget.connect_done + 1
                widget.status = {}

            elif action == "rebind":
                report_ids = data.get("report_ids") or []
                target_ds = data.get("dataset_id")
                target_ds_ws = data.get("dataset_workspace_id") or ws_id
                if not report_ids or not target_ds:
                    widget.status = {
                        "message": "Select a target semantic model to rebind.",
                        "kind": "error",
                    }
                    return
                report_rebind(
                    report=[str(x) for x in report_ids],
                    dataset=str(target_ds),
                    report_workspace=ws_id,
                    dataset_workspace=str(target_ds_ws),
                )
                # Rebound reports drop out of this model's lineage; reload.
                keep = widget.analyzed
                widget.reports = _build_reports(analyze=keep)
                widget.rebind_done = widget.rebind_done + 1
                widget.status = {
                    "message": (
                        f"Rebound {len(report_ids)} report"
                        f"{'' if len(report_ids) == 1 else 's'} to the selected "
                        "semantic model."
                    ),
                    "kind": "success",
                }

            elif action == "save_fixes":
                fixes = data.get("fixes") or []
                if not fixes:
                    return

                # Group staged fixes by the report they apply to.
                by_report = {}
                for f in fixes:
                    by_report.setdefault(f.get("reportId"), []).append(f)

                saved = 0
                for report_id, flist in by_report.items():
                    if not report_id:
                        continue
                    report_fixes = []
                    for f in flist:
                        target_name = f.get("targetName") or ""
                        if not target_name:
                            continue
                        report_fixes.append(
                            {
                                "objectType": f.get("objectType") or "",
                                "oldTable": f.get("brokenTable") or "",
                                "oldName": f.get("brokenName") or "",
                                "oldHierarchy": f.get("brokenHierarchy") or "",
                                "newTable": f.get("targetTable") or "",
                                "newName": target_name,
                                "newHierarchy": f.get("targetHierarchy") or "",
                            }
                        )
                    if not report_fixes:
                        continue
                    _apply_report_fixes(report_id, report_fixes)
                    saved += len(report_fixes)

                # Re-analyze so the fixed objects drop off the broken list.
                keep = widget.analyzed
                widget.reports = _build_reports(analyze=keep)
                widget.fixes_saved = widget.fixes_saved + 1
                widget.status = {
                    "message": f"Saved {saved} fix{'' if saved == 1 else 'es'}.",
                    "kind": "success",
                }
        except Exception as e:
            widget.status = {"message": f"Error: {e}", "kind": "error"}
        finally:
            widget.busy = False

    widget.observe(_on_run, names=["run"])

    display(widget)
